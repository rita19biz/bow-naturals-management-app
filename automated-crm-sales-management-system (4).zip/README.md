# Bow Naturals - Business Management System

A comprehensive business management system built with React, TypeScript, and Tailwind CSS.

## Features

- 🔐 **Multi-role Authentication** - CEO and Staff roles with data isolation
- 📦 **CRM Dashboard** - Track orders with delivery cost and logistics location
- 💰 **Sales Tracker** - Auto-tracks delivered orders with flexible date filtering
- 💸 **Expense Management** - Track expenses by category with date ranges
- 📊 **Profit Analytics** - Daily, weekly, monthly, yearly profit analysis
- 📦 **Inventory Management** - Products with order-type based pricing (Retail/Wholesale/DM-Group)
- 🚚 **Logistics Management** - Track inventory across multiple logistics locations
- 👥 **Staff Management** - Add/manage staff accounts

## Default Login

- **Username:** `admin`
- **Password:** `admin123`

---

## 🚀 Deployment Guide

### Option 1: Deploy to Vercel (Recommended)

**Step 1: Create a GitHub Repository**
1. Go to [github.com](https://github.com) and sign in (or create account)
2. Click the "+" icon → "New repository"
3. Name it `bow-naturals-management`
4. Keep it Public or Private
5. Click "Create repository"

**Step 2: Upload Code to GitHub**
1. Download all files from this project
2. In your new GitHub repo, click "uploading an existing file"
3. Drag and drop ALL project files
4. Click "Commit changes"

**Step 3: Deploy on Vercel**
1. Go to [vercel.com](https://vercel.com)
2. Click "Sign Up" → "Continue with GitHub"
3. Authorize Vercel to access your GitHub
4. Click "New Project"
5. Find and select your `bow-naturals-management` repo
6. Click "Deploy"
7. Wait 1-2 minutes for deployment
8. 🎉 Your app is live! You'll get a URL like: `bow-naturals-management.vercel.app`

**Step 4: Add Custom Domain (Optional)**
1. In Vercel, go to your project → Settings → Domains
2. Add your domain (e.g., `app.bownaturals.com`)
3. Follow the DNS instructions provided
4. SSL certificate is automatic!

---

### Option 2: Deploy to Netlify

**Step 1: Prepare the Build**
If deploying manually, first build the project:
```bash
npm install
npm run build
```

**Step 2: Deploy**
1. Go to [netlify.com](https://netlify.com)
2. Sign up with GitHub
3. Either:
   - **Option A:** Drag and drop the `dist` folder to Netlify
   - **Option B:** Connect your GitHub repo for auto-deploys

**Step 3: Configure**
- Build command: `npm run build`
- Publish directory: `dist`

---

### Option 3: Deploy to Railway

1. Go to [railway.app](https://railway.app)
2. Connect GitHub
3. Select your repository
4. Railway auto-detects the build settings
5. Deploy!

---

## 📁 Project Structure

```
├── src/
│   ├── components/       # React components
│   │   ├── Login.tsx
│   │   ├── Dashboard.tsx
│   │   ├── CRM.tsx
│   │   ├── SalesTracker.tsx
│   │   ├── Expenses.tsx
│   │   ├── ProfitAnalytics.tsx
│   │   ├── Inventory.tsx
│   │   ├── LogisticsManagement.tsx
│   │   ├── StaffManagement.tsx
│   │   ├── CompanySettings.tsx
│   │   ├── Sidebar.tsx
│   │   └── MobileHeader.tsx
│   ├── context/          # State management
│   │   └── AppContext.tsx
│   ├── types/            # TypeScript types
│   │   └── index.ts
│   ├── App.tsx           # Main app component
│   ├── main.tsx          # Entry point
│   └── index.css         # Styles
├── index.html
├── package.json
├── vercel.json           # Vercel config
├── netlify.toml          # Netlify config
└── README.md
```

---

## 🔧 Local Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

---

## 📝 Data Storage

This app uses **browser localStorage** for data persistence. This means:
- ✅ Data persists between sessions on the same browser
- ✅ No server/database required
- ⚠️ Data is specific to each browser/device
- ⚠️ Clearing browser data will reset the app

For a production environment with multiple users on different devices, you would need to integrate a backend database (Firebase, Supabase, etc.).

---

## 🔒 Security Notes

- Change the default admin password after first login
- Each staff member only sees their own data
- CEO has full access to all data and settings
- Sensitive data is stored in browser localStorage

---

## 📞 Support

For issues or feature requests, please create an issue in the GitHub repository.

---

## License

MIT License - Feel free to use and modify for your business needs.
