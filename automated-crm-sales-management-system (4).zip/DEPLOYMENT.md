# 🚀 Quick Deployment Guide

## Fastest Way: Vercel (5 minutes)

### Step 1: Get a GitHub Account
If you don't have one, go to **github.com** and sign up (it's free).

### Step 2: Create a New Repository
1. Click the **+** button (top right) → **New repository**
2. Name: `bow-naturals-app`
3. Click **Create repository**

### Step 3: Upload Your Files
1. On your new repo page, click **"uploading an existing file"**
2. Drag ALL the project files into the upload area
3. Click **Commit changes**

### Step 4: Deploy to Vercel
1. Go to **vercel.com**
2. Click **Sign Up** → **Continue with GitHub**
3. Click **New Project**
4. Select your `bow-naturals-app` repository
5. Click **Deploy**
6. Wait ~2 minutes...
7. ✅ **DONE!** Your app is live!

### Step 5: Access Your App
Vercel will give you a URL like:
```
https://bow-naturals-app.vercel.app
```

---

## Adding a Custom Domain

### If you have a domain (e.g., bownaturals.com):

1. In Vercel → Your Project → **Settings** → **Domains**
2. Click **Add**
3. Enter your domain: `app.bownaturals.com`
4. Vercel will show you DNS records to add

### Add DNS Records at Your Domain Provider:
- Go to your domain provider (GoDaddy, Namecheap, etc.)
- Add the DNS records Vercel shows you
- Wait 5-30 minutes for propagation
- ✅ Your custom domain is ready!

---

## Login Credentials

After deployment, login with:

| Field | Value |
|-------|-------|
| Username | `admin` |
| Password | `admin123` |

⚠️ **Change this password** in Company Settings after first login!

---

## Files You Need to Upload

Make sure to upload ALL these files/folders:

```
📁 src/
📁 public/ (if exists)
📄 index.html
📄 package.json
📄 package-lock.json
📄 tsconfig.json
📄 vite.config.ts
📄 vercel.json
📄 netlify.toml
📄 .gitignore
📄 README.md
```

---

## Troubleshooting

### Build Failed?
- Make sure all files are uploaded
- Check that `package.json` is in the root folder

### App Shows Blank Page?
- Clear browser cache
- Try incognito/private mode

### Can't Login?
- Use exactly: `admin` / `admin123`
- Clear localStorage: Open browser console (F12) → Run: `localStorage.clear()`

---

## Need Help?

1. Check the error message in Vercel dashboard
2. Make sure all files are uploaded correctly
3. Verify the build command is `npm run build`
