# 📦 Cloudflare Pages Upload Instructions

## Files to Upload

You need to upload the **`dist`** folder contents:

```
dist/
  ├── index.html      (your entire app)
  ├── _redirects      (for page routing)
  └── _headers        (security headers)
```

---

## 🚀 Upload Steps

### Step 1: Download the `dist` folder
Download these 3 files from the `dist` folder:
- `index.html`
- `_redirects`
- `_headers`

### Step 2: Go to Cloudflare
1. Log into **[dash.cloudflare.com](https://dash.cloudflare.com)**
2. Click **"Workers & Pages"** (left sidebar)
3. Click **"Create"**
4. Select **"Pages"**
5. Click **"Upload assets"**

### Step 3: Upload
1. Project name: `bow-naturals` (or any name you want)
2. **Drag & drop** the 3 files (index.html, _redirects, _headers)
3. Click **"Deploy site"**

### Step 4: Connect Your Domain
1. After deploy completes, click **"Custom domains"**
2. Click **"Set up a custom domain"**
3. Enter your domain: `app.yourdomain.com`
4. Click **"Continue"**
5. Cloudflare auto-configures everything! ✅

---

## 🔑 Login After Deployment

```
Username: admin
Password: admin123
```

---

## ✅ That's It!

Your app will be live at:
- `bow-naturals.pages.dev` (free subdomain)
- `app.yourdomain.com` (your custom domain)

---

## Troubleshooting

**Blank page?**
- Make sure you uploaded all 3 files
- Clear browser cache (Ctrl+Shift+R)

**Can't login?**
- Use exactly: `admin` / `admin123`
- Try incognito/private mode

**Domain not working?**
- Wait 1-2 minutes for DNS
- Make sure domain is active in Cloudflare
