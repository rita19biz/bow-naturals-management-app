export interface User {
  id: string;
  username: string;
  password: string;
  name: string;
  role: 'ceo' | 'staff';
  createdAt: string;
}

export interface PriceTier {
  minQuantity: number;
  maxQuantity: number | null;
  price: number;
}

export interface OrderTypePricing {
  retail: PriceTier[];
  wholesale: PriceTier[];
  dm_group: PriceTier[];
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  category: string;
  description: string;
  pricing: OrderTypePricing;
  costPrice: number;
  stock: number;
  minStock: number;
  unit: string;
  createdAt: string;
}

export interface LogisticsCompany {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  inventory: {
    productId: string;
    quantity: number;
  }[];
  createdAt: string;
}

export type OrderType = 'retail' | 'wholesale' | 'dm_group';

export interface CRMEntry {
  id: string;
  staffId: string;
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  customerAddress: string;
  orderType: OrderType;
  products: {
    productId: string;
    productName: string;
    quantity: number;
    unitPrice: number;
    total: number;
  }[];
  totalAmount: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  actualDeliveryDate: string | null;
  deliveryCost: number;
  deliveredFrom: string | null; // Logistics company ID
  followUpDate: string | null;
  followUpStatus: 'pending' | 'completed' | 'overdue';
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface SalesEntry {
  id: string;
  staffId: string;
  crmId: string | null;
  customerName: string;
  orderType: OrderType;
  products: {
    productId: string;
    productName: string;
    quantity: number;
    unitPrice: number;
    costPrice: number;
    total: number;
  }[];
  totalAmount: number;
  deliveryCost: number;
  costAmount: number;
  profit: number;
  paymentMethod: string;
  saleDate: string;
  createdAt: string;
}

export interface Expense {
  id: string;
  staffId: string;
  category: string;
  description: string;
  amount: number;
  date: string;
  receipt: string;
  createdAt: string;
}

export interface CompanySettings {
  name: string;
  logo: string;
  address: string;
  phone: string;
  email: string;
  currency: string;
  taxRate: number;
}
