import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { addDays, format, isAfter, isBefore, parseISO, startOfDay, endOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth, startOfYear, endOfYear } from 'date-fns';
import { User, Product, CRMEntry, SalesEntry, Expense, CompanySettings, LogisticsCompany, OrderType } from '../types';

interface DateRange {
  start: Date;
  end: Date;
}

interface AppContextType {
  // Auth
  currentUser: User | null;
  users: User[];
  login: (username: string, password: string) => boolean;
  logout: () => void;
  addUser: (user: Omit<User, 'id' | 'createdAt'>) => void;
  updateUser: (id: string, user: Partial<User>) => void;
  deleteUser: (id: string) => void;

  // Products
  products: Product[];
  addProduct: (product: Omit<Product, 'id' | 'createdAt'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  getProductPrice: (productId: string, quantity: number, orderType: OrderType) => number;

  // Logistics
  logisticsCompanies: LogisticsCompany[];
  addLogisticsCompany: (company: Omit<LogisticsCompany, 'id' | 'createdAt'>) => void;
  updateLogisticsCompany: (id: string, company: Partial<LogisticsCompany>) => void;
  deleteLogisticsCompany: (id: string) => void;
  addInventoryToLogistics: (companyId: string, productId: string, quantity: number) => void;
  deductFromLogistics: (companyId: string, productId: string, quantity: number) => void;

  // CRM
  crmEntries: CRMEntry[];
  addCRMEntry: (entry: Omit<CRMEntry, 'id' | 'createdAt' | 'updatedAt' | 'followUpDate' | 'followUpStatus'>) => void;
  updateCRMEntry: (id: string, entry: Partial<CRMEntry>) => void;
  deleteCRMEntry: (id: string) => void;
  markAsDelivered: (id: string, deliveryDate: string, deliveryCost: number, deliveredFrom: string) => void;
  getFilteredCRM: (staffId?: string) => CRMEntry[];
  getFollowUps: (staffId?: string) => CRMEntry[];

  // Sales
  salesEntries: SalesEntry[];
  addSalesEntry: (entry: Omit<SalesEntry, 'id' | 'createdAt'>) => void;
  updateSalesEntry: (id: string, entry: Partial<SalesEntry>) => void;
  deleteSalesEntry: (id: string) => void;
  getFilteredSales: (staffId?: string, dateRange?: DateRange) => SalesEntry[];

  // Expenses
  expenses: Expense[];
  addExpense: (expense: Omit<Expense, 'id' | 'createdAt'>) => void;
  updateExpense: (id: string, expense: Partial<Expense>) => void;
  deleteExpense: (id: string) => void;
  getFilteredExpenses: (staffId?: string, dateRange?: DateRange) => Expense[];

  // Analytics
  getProfitAnalytics: (period: 'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom', staffId?: string, dateRange?: DateRange) => {
    totalSales: number;
    totalDeliveryCost: number;
    totalExpenses: number;
    totalProfit: number;
    salesCount: number;
  };

  // Company Settings
  companySettings: CompanySettings;
  updateCompanySettings: (settings: Partial<CompanySettings>) => void;

  // View Mode
  selectedStaffId: string;
  setSelectedStaffId: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const defaultCompanySettings: CompanySettings = {
  name: 'Bow Naturals',
  logo: '',
  address: '123 Business Street',
  phone: '+1234567890',
  email: 'info@bownaturals.com',
  currency: '₦',
  taxRate: 7.5,
};

const defaultUsers: User[] = [
  {
    id: 'ceo-001',
    username: 'admin',
    password: 'admin123',
    name: 'CEO Admin',
    role: 'ceo',
    createdAt: new Date().toISOString(),
  },
];



const sampleProducts: Product[] = [
  {
    id: 'prod-001',
    name: 'Natural Hair Oil',
    sku: 'NHO-001',
    category: 'Hair Care',
    description: 'Premium natural hair oil for healthy hair',
    pricing: {
      retail: [
        { minQuantity: 1, maxQuantity: 5, price: 5000 },
        { minQuantity: 6, maxQuantity: 20, price: 4800 },
        { minQuantity: 21, maxQuantity: null, price: 4500 },
      ],
      wholesale: [
        { minQuantity: 1, maxQuantity: 10, price: 4000 },
        { minQuantity: 11, maxQuantity: 50, price: 3800 },
        { minQuantity: 51, maxQuantity: null, price: 3500 },
      ],
      dm_group: [
        { minQuantity: 1, maxQuantity: 5, price: 4500 },
        { minQuantity: 6, maxQuantity: 20, price: 4200 },
        { minQuantity: 21, maxQuantity: null, price: 4000 },
      ],
    },
    costPrice: 2500,
    stock: 100,
    minStock: 20,
    unit: 'bottle',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'prod-002',
    name: 'Organic Body Butter',
    sku: 'OBB-001',
    category: 'Skin Care',
    description: 'Organic body butter for smooth skin',
    pricing: {
      retail: [
        { minQuantity: 1, maxQuantity: 3, price: 8000 },
        { minQuantity: 4, maxQuantity: 10, price: 7500 },
        { minQuantity: 11, maxQuantity: null, price: 7000 },
      ],
      wholesale: [
        { minQuantity: 1, maxQuantity: 10, price: 6500 },
        { minQuantity: 11, maxQuantity: 30, price: 6000 },
        { minQuantity: 31, maxQuantity: null, price: 5500 },
      ],
      dm_group: [
        { minQuantity: 1, maxQuantity: 5, price: 7200 },
        { minQuantity: 6, maxQuantity: 15, price: 6800 },
        { minQuantity: 16, maxQuantity: null, price: 6500 },
      ],
    },
    costPrice: 4000,
    stock: 75,
    minStock: 15,
    unit: 'jar',
    createdAt: new Date().toISOString(),
  },
];

const sampleLogistics: LogisticsCompany[] = [
  {
    id: 'log-001',
    name: 'Lagos Hub',
    phone: '+234 801 234 5678',
    email: 'lagos@logistics.com',
    address: 'Victoria Island, Lagos',
    inventory: [
      { productId: 'prod-001', quantity: 50 },
      { productId: 'prod-002', quantity: 30 },
    ],
    createdAt: new Date().toISOString(),
  },
  {
    id: 'log-002',
    name: 'Abuja Hub',
    phone: '+234 802 345 6789',
    email: 'abuja@logistics.com',
    address: 'Wuse 2, Abuja',
    inventory: [
      { productId: 'prod-001', quantity: 25 },
      { productId: 'prod-002', quantity: 20 },
    ],
    createdAt: new Date().toISOString(),
  },
];

export function AppProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('bow_users');
    return saved ? JSON.parse(saved) : defaultUsers;
  });
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('bow_products');
    return saved ? JSON.parse(saved) : sampleProducts;
  });
  const [logisticsCompanies, setLogisticsCompanies] = useState<LogisticsCompany[]>(() => {
    const saved = localStorage.getItem('bow_logistics');
    return saved ? JSON.parse(saved) : sampleLogistics;
  });
  const [crmEntries, setCRMEntries] = useState<CRMEntry[]>(() => {
    const saved = localStorage.getItem('bow_crm');
    return saved ? JSON.parse(saved) : [];
  });
  const [salesEntries, setSalesEntries] = useState<SalesEntry[]>(() => {
    const saved = localStorage.getItem('bow_sales');
    return saved ? JSON.parse(saved) : [];
  });
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('bow_expenses');
    return saved ? JSON.parse(saved) : [];
  });
  const [companySettings, setCompanySettings] = useState<CompanySettings>(() => {
    const saved = localStorage.getItem('bow_settings');
    return saved ? JSON.parse(saved) : defaultCompanySettings;
  });
  const [selectedStaffId, setSelectedStaffId] = useState<string>('all');

  // Persist data
  useEffect(() => {
    localStorage.setItem('bow_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('bow_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('bow_logistics', JSON.stringify(logisticsCompanies));
  }, [logisticsCompanies]);

  useEffect(() => {
    localStorage.setItem('bow_crm', JSON.stringify(crmEntries));
  }, [crmEntries]);

  useEffect(() => {
    localStorage.setItem('bow_sales', JSON.stringify(salesEntries));
  }, [salesEntries]);

  useEffect(() => {
    localStorage.setItem('bow_expenses', JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem('bow_settings', JSON.stringify(companySettings));
  }, [companySettings]);

  // Check for session
  useEffect(() => {
    const session = localStorage.getItem('bow_session');
    if (session) {
      const user = users.find(u => u.id === session);
      if (user) setCurrentUser(user);
    }
  }, []);

  // Auto-update follow-up status
  useEffect(() => {
    const updatedEntries = crmEntries.map(entry => {
      if (entry.status === 'delivered' && entry.followUpDate) {
        const followUpDate = parseISO(entry.followUpDate);
        const today = new Date();
        if (isBefore(followUpDate, today) && entry.followUpStatus === 'pending') {
          return { ...entry, followUpStatus: 'overdue' as const };
        }
      }
      return entry;
    });
    
    const hasChanges = updatedEntries.some((entry, i) => entry.followUpStatus !== crmEntries[i]?.followUpStatus);
    if (hasChanges) {
      setCRMEntries(updatedEntries);
    }
  }, []);

  // Auth functions
  const login = (username: string, password: string): boolean => {
    const user = users.find(u => u.username === username && u.password === password);
    if (user) {
      setCurrentUser(user);
      localStorage.setItem('bow_session', user.id);
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('bow_session');
  };

  const addUser = (user: Omit<User, 'id' | 'createdAt'>) => {
    const newUser: User = {
      ...user,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    };
    setUsers(prev => [...prev, newUser]);
  };

  const updateUser = (id: string, updates: Partial<User>) => {
    setUsers(prev => prev.map(u => u.id === id ? { ...u, ...updates } : u));
  };

  const deleteUser = (id: string) => {
    setUsers(prev => prev.filter(u => u.id !== id));
  };

  // Product functions
  const getProductPrice = (productId: string, quantity: number, orderType: OrderType): number => {
    const product = products.find(p => p.id === productId);
    if (!product) return 0;
    
    const priceTiers = product.pricing[orderType] || product.pricing.retail;
    const tier = priceTiers.find(t => 
      quantity >= t.minQuantity && (t.maxQuantity === null || quantity <= t.maxQuantity)
    );
    return tier?.price || priceTiers[0]?.price || 0;
  };

  const addProduct = (product: Omit<Product, 'id' | 'createdAt'>) => {
    const newProduct: Product = {
      ...product,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    };
    setProducts(prev => [...prev, newProduct]);
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  // Logistics functions
  const addLogisticsCompany = (company: Omit<LogisticsCompany, 'id' | 'createdAt'>) => {
    const newCompany: LogisticsCompany = {
      ...company,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    };
    setLogisticsCompanies(prev => [...prev, newCompany]);
  };

  const updateLogisticsCompany = (id: string, updates: Partial<LogisticsCompany>) => {
    setLogisticsCompanies(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
  };

  const deleteLogisticsCompany = (id: string) => {
    setLogisticsCompanies(prev => prev.filter(c => c.id !== id));
  };

  const addInventoryToLogistics = (companyId: string, productId: string, quantity: number) => {
    setLogisticsCompanies(prev => prev.map(company => {
      if (company.id === companyId) {
        const existingItem = company.inventory.find(i => i.productId === productId);
        if (existingItem) {
          return {
            ...company,
            inventory: company.inventory.map(i =>
              i.productId === productId ? { ...i, quantity: i.quantity + quantity } : i
            ),
          };
        } else {
          return {
            ...company,
            inventory: [...company.inventory, { productId, quantity }],
          };
        }
      }
      return company;
    }));
  };

  const deductFromLogistics = (companyId: string, productId: string, quantity: number) => {
    setLogisticsCompanies(prev => prev.map(company => {
      if (company.id === companyId) {
        return {
          ...company,
          inventory: company.inventory.map(i =>
            i.productId === productId ? { ...i, quantity: Math.max(0, i.quantity - quantity) } : i
          ).filter(i => i.quantity > 0),
        };
      }
      return company;
    }));
  };

  // CRM functions
  const addCRMEntry = (entry: Omit<CRMEntry, 'id' | 'createdAt' | 'updatedAt' | 'followUpDate' | 'followUpStatus'>) => {
    const now = new Date().toISOString();
    const newEntry: CRMEntry = {
      ...entry,
      id: uuidv4(),
      followUpDate: null,
      followUpStatus: 'pending',
      createdAt: now,
      updatedAt: now,
    };
    setCRMEntries(prev => [...prev, newEntry]);
  };

  const updateCRMEntry = (id: string, updates: Partial<CRMEntry>) => {
    setCRMEntries(prev => prev.map(e => e.id === id ? { ...e, ...updates, updatedAt: new Date().toISOString() } : e));
  };

  const deleteCRMEntry = (id: string) => {
    setCRMEntries(prev => prev.filter(e => e.id !== id));
  };

  const markAsDelivered = (id: string, deliveryDate: string, deliveryCost: number, deliveredFrom: string) => {
    const followUpDate = format(addDays(parseISO(deliveryDate), 30), 'yyyy-MM-dd');
    
    const entry = crmEntries.find(e => e.id === id);
    if (!entry) return;

    // Deduct from logistics inventory
    if (deliveredFrom) {
      entry.products.forEach(p => {
        deductFromLogistics(deliveredFrom, p.productId, p.quantity);
      });
    }

    setCRMEntries(prev => prev.map(e => {
      if (e.id === id) {
        return {
          ...e,
          status: 'delivered' as const,
          actualDeliveryDate: deliveryDate,
          deliveryCost,
          deliveredFrom,
          followUpDate,
          followUpStatus: 'pending' as const,
          updatedAt: new Date().toISOString(),
        };
      }
      return e;
    }));

    // Create sales entry
    const salesEntry: SalesEntry = {
      id: uuidv4(),
      staffId: entry.staffId,
      crmId: entry.id,
      customerName: entry.customerName,
      orderType: entry.orderType,
      products: entry.products.map(p => {
        const product = products.find(prod => prod.id === p.productId);
        return {
          ...p,
          costPrice: product?.costPrice || 0,
        };
      }),
      totalAmount: entry.totalAmount,
      deliveryCost,
      costAmount: entry.products.reduce((sum, p) => {
        const product = products.find(prod => prod.id === p.productId);
        return sum + (product?.costPrice || 0) * p.quantity;
      }, 0),
      profit: entry.totalAmount - deliveryCost - entry.products.reduce((sum, p) => {
        const product = products.find(prod => prod.id === p.productId);
        return sum + (product?.costPrice || 0) * p.quantity;
      }, 0),
      paymentMethod: 'cash',
      saleDate: deliveryDate,
      createdAt: new Date().toISOString(),
    };
    
    setSalesEntries(prev => [...prev, salesEntry]);
  };

  const getFilteredCRM = (staffId?: string): CRMEntry[] => {
    if (!staffId || staffId === 'all') return crmEntries;
    return crmEntries.filter(e => e.staffId === staffId);
  };

  const getFollowUps = (staffId?: string): CRMEntry[] => {
    const filtered = getFilteredCRM(staffId);
    return filtered.filter(e => 
      e.status === 'delivered' && 
      e.followUpDate && 
      (e.followUpStatus === 'pending' || e.followUpStatus === 'overdue')
    );
  };

  // Sales functions
  const addSalesEntry = (entry: Omit<SalesEntry, 'id' | 'createdAt'>) => {
    const newEntry: SalesEntry = {
      ...entry,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    };
    setSalesEntries(prev => [...prev, newEntry]);
  };

  const updateSalesEntry = (id: string, updates: Partial<SalesEntry>) => {
    setSalesEntries(prev => prev.map(e => e.id === id ? { ...e, ...updates } : e));
  };

  const deleteSalesEntry = (id: string) => {
    setSalesEntries(prev => prev.filter(e => e.id !== id));
  };

  const getFilteredSales = (staffId?: string, dateRange?: DateRange): SalesEntry[] => {
    let filtered = salesEntries;
    
    if (staffId && staffId !== 'all') {
      filtered = filtered.filter(e => e.staffId === staffId);
    }
    
    if (dateRange) {
      filtered = filtered.filter(e => {
        const saleDate = parseISO(e.saleDate);
        return !isBefore(saleDate, dateRange.start) && !isAfter(saleDate, dateRange.end);
      });
    }
    
    return filtered;
  };

  // Expense functions
  const addExpense = (expense: Omit<Expense, 'id' | 'createdAt'>) => {
    const newExpense: Expense = {
      ...expense,
      id: uuidv4(),
      createdAt: new Date().toISOString(),
    };
    setExpenses(prev => [...prev, newExpense]);
  };

  const updateExpense = (id: string, updates: Partial<Expense>) => {
    setExpenses(prev => prev.map(e => e.id === id ? { ...e, ...updates } : e));
  };

  const deleteExpense = (id: string) => {
    setExpenses(prev => prev.filter(e => e.id !== id));
  };

  const getFilteredExpenses = (staffId?: string, dateRange?: DateRange): Expense[] => {
    let filtered = expenses;
    
    if (staffId && staffId !== 'all') {
      filtered = filtered.filter(e => e.staffId === staffId);
    }
    
    if (dateRange) {
      filtered = filtered.filter(e => {
        const expenseDate = parseISO(e.date);
        return !isBefore(expenseDate, dateRange.start) && !isAfter(expenseDate, dateRange.end);
      });
    }
    
    return filtered;
  };

  // Analytics
  const getProfitAnalytics = (period: 'daily' | 'weekly' | 'monthly' | 'yearly' | 'custom', staffId?: string, dateRange?: DateRange) => {
    const now = new Date();
    let startDate: Date, endDate: Date;

    if (period === 'custom' && dateRange) {
      startDate = dateRange.start;
      endDate = dateRange.end;
    } else {
      switch (period) {
        case 'daily':
          startDate = startOfDay(now);
          endDate = endOfDay(now);
          break;
        case 'weekly':
          startDate = startOfWeek(now, { weekStartsOn: 1 });
          endDate = endOfWeek(now, { weekStartsOn: 1 });
          break;
        case 'monthly':
          startDate = startOfMonth(now);
          endDate = endOfMonth(now);
          break;
        case 'yearly':
          startDate = startOfYear(now);
          endDate = endOfYear(now);
          break;
        default:
          startDate = startOfDay(now);
          endDate = endOfDay(now);
      }
    }

    const filteredSales = getFilteredSales(staffId, { start: startDate, end: endDate });
    const filteredExpenses = getFilteredExpenses(staffId, { start: startDate, end: endDate });

    const totalSales = filteredSales.reduce((sum, s) => sum + s.totalAmount, 0);
    const totalDeliveryCost = filteredSales.reduce((sum, s) => sum + (s.deliveryCost || 0), 0);
    const totalExpenses = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);
    const totalProfit = totalSales - totalDeliveryCost - totalExpenses - filteredSales.reduce((sum, s) => sum + s.costAmount, 0);

    return {
      totalSales,
      totalDeliveryCost,
      totalExpenses,
      totalProfit,
      salesCount: filteredSales.length,
    };
  };

  const updateCompanySettings = (settings: Partial<CompanySettings>) => {
    setCompanySettings(prev => ({ ...prev, ...settings }));
  };

  return (
    <AppContext.Provider value={{
      currentUser,
      users,
      login,
      logout,
      addUser,
      updateUser,
      deleteUser,
      products,
      addProduct,
      updateProduct,
      deleteProduct,
      getProductPrice,
      logisticsCompanies,
      addLogisticsCompany,
      updateLogisticsCompany,
      deleteLogisticsCompany,
      addInventoryToLogistics,
      deductFromLogistics,
      crmEntries,
      addCRMEntry,
      updateCRMEntry,
      deleteCRMEntry,
      markAsDelivered,
      getFilteredCRM,
      getFollowUps,
      salesEntries,
      addSalesEntry,
      updateSalesEntry,
      deleteSalesEntry,
      getFilteredSales,
      expenses,
      addExpense,
      updateExpense,
      deleteExpense,
      getFilteredExpenses,
      getProfitAnalytics,
      companySettings,
      updateCompanySettings,
      selectedStaffId,
      setSelectedStaffId,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
}
