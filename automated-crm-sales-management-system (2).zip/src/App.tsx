import { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import Login from './components/Login';
import Sidebar from './components/Sidebar';
import MobileHeader from './components/MobileHeader';
import Dashboard from './components/Dashboard';
import CRM from './components/CRM';
import SalesTracker from './components/SalesTracker';
import Expenses from './components/Expenses';
import ProfitAnalytics from './components/ProfitAnalytics';
import Inventory from './components/Inventory';
import LogisticsManagement from './components/LogisticsManagement';
import StaffManagement from './components/StaffManagement';
import CompanySettings from './components/CompanySettings';

function MainApp() {
  const { currentUser } = useApp();
  const [activeTab, setActiveTab] = useState('dashboard');

  if (!currentUser) {
    return <Login />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'crm':
        return <CRM />;
      case 'sales':
        return <SalesTracker />;
      case 'expenses':
        return <Expenses />;
      case 'profits':
        return <ProfitAnalytics />;
      case 'inventory':
        return <Inventory />;
      case 'logistics':
        return <LogisticsManagement />;
      case 'staff':
        return <StaffManagement />;
      case 'settings':
        return <CompanySettings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex min-h-screen bg-gray-50">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      </div>
      
      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile Header */}
        <MobileHeader activeTab={activeTab} setActiveTab={setActiveTab} />
        
        {/* Content Area */}
        <div className="flex-1 overflow-auto">
          {renderContent()}
        </div>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
