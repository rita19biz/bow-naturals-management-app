import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { format, parseISO } from 'date-fns';
import {
  Plus,
  Edit2,
  Trash2,
  X,
  User,
  Shield,
  Eye,
  EyeOff,
  UserCog,
  Lock,
} from 'lucide-react';

export default function StaffManagement() {
  const {
    users,
    addUser,
    updateUser,
    deleteUser,
    getFilteredCRM,
    getFilteredSales,
    companySettings,
  } = useApp();

  const staffMembers = users.filter(u => u.role === 'staff');
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [showPassword, setShowPassword] = useState(false);

  const [formData, setFormData] = useState({
    username: '',
    password: '',
    name: '',
    role: 'staff' as 'ceo' | 'staff',
  });

  const resetForm = () => {
    setFormData({
      username: '',
      password: '',
      name: '',
      role: 'staff',
    });
    setEditingId(null);
    setShowForm(false);
    setShowPassword(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (editingId) {
      const updates: Partial<typeof formData> = { 
        name: formData.name, 
        username: formData.username,
        role: formData.role,
      };
      if (formData.password) {
        updates.password = formData.password;
      }
      updateUser(editingId, updates);
    } else {
      addUser(formData);
    }
    resetForm();
  };

  const handleEdit = (user: typeof users[0]) => {
    setFormData({
      username: user.username,
      password: '',
      name: user.name,
      role: user.role,
    });
    setEditingId(user.id);
    setShowForm(true);
  };

  const getStaffStats = (staffId: string) => {
    const crmEntries = getFilteredCRM(staffId);
    const salesEntries = getFilteredSales(staffId);
    const totalOrders = crmEntries.length;
    const deliveredOrders = crmEntries.filter(e => e.status === 'delivered').length;
    const totalSales = salesEntries.reduce((sum, s) => sum + s.totalAmount, 0);
    const totalProfit = salesEntries.reduce((sum, s) => sum + s.profit, 0);
    
    return { totalOrders, deliveredOrders, totalSales, totalProfit };
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Staff Management</h1>
          <p className="text-gray-500">Manage staff accounts and permissions</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-500 to-green-600 text-white rounded-lg hover:from-emerald-600 hover:to-green-700 transition shadow-lg shadow-emerald-200"
        >
          <Plus className="w-5 h-5" />
          Add Staff
        </button>
      </div>

      {/* Staff Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {staffMembers.length === 0 ? (
          <div className="col-span-full bg-white rounded-xl p-12 text-center text-gray-400 shadow-sm border border-gray-100">
            <UserCog className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No staff members yet</p>
            <button
              onClick={() => setShowForm(true)}
              className="mt-4 text-emerald-600 hover:text-emerald-700 font-medium"
            >
              Add your first staff member
            </button>
          </div>
        ) : (
          staffMembers.map((staff) => {
            const stats = getStaffStats(staff.id);
            return (
              <div key={staff.id} className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-emerald-400 to-green-500 rounded-xl flex items-center justify-center text-white font-bold text-lg">
                      {staff.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{staff.name}</h3>
                      <p className="text-sm text-gray-500">@{staff.username}</p>
                    </div>
                  </div>
                  <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-medium capitalize">
                    {staff.role}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-500">Total Orders</p>
                    <p className="text-lg font-bold text-gray-900">{stats.totalOrders}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-500">Delivered</p>
                    <p className="text-lg font-bold text-green-600">{stats.deliveredOrders}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-500">Total Sales</p>
                    <p className="text-lg font-bold text-gray-900">
                      {companySettings.currency}{stats.totalSales.toLocaleString()}
                    </p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-500">Profit Generated</p>
                    <p className={`text-lg font-bold ${stats.totalProfit >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                      {companySettings.currency}{stats.totalProfit.toLocaleString()}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <p className="text-xs text-gray-400">
                    Joined {format(parseISO(staff.createdAt), 'MMM d, yyyy')}
                  </p>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleEdit(staff)}
                      className="p-2 text-gray-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Are you sure you want to delete ${staff.name}? This will not delete their orders.`)) {
                          deleteUser(staff.id);
                        }
                      }}
                      className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* CEO Account Info */}
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-6 text-white">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-14 h-14 bg-white/10 rounded-xl flex items-center justify-center">
            <Shield className="w-7 h-7" />
          </div>
          <div>
            <h3 className="text-lg font-semibold">Administrator Account</h3>
            <p className="text-gray-400 text-sm">Full access to all features and data</p>
          </div>
        </div>
        <div className="bg-white/10 rounded-lg p-4">
          <p className="text-sm text-gray-300 mb-2">CEO accounts have access to:</p>
          <ul className="text-sm text-gray-400 space-y-1">
            <li>• View all staff orders and performance</li>
            <li>• Manage inventory and product pricing</li>
            <li>• Access complete profit analytics</li>
            <li>• Manage staff accounts</li>
            <li>• Configure company settings</li>
          </ul>
        </div>
      </div>

      {/* Add/Edit Staff Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-xl">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">
                {editingId ? 'Edit Staff' : 'Add Staff'}
              </h3>
              <button
                onClick={resetForm}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name *
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                    placeholder="John Doe"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Username *
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">@</span>
                  <input
                    type="text"
                    required
                    value={formData.username}
                    onChange={(e) => setFormData(prev => ({ ...prev, username: e.target.value.toLowerCase().replace(/\s/g, '') }))}
                    className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                    placeholder="johndoe"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Password {editingId ? '(leave empty to keep current)' : '*'}
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required={!editingId}
                    value={formData.password}
                    onChange={(e) => setFormData(prev => ({ ...prev, password: e.target.value }))}
                    className="w-full pl-10 pr-12 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                    placeholder="••••••••"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                <p className="text-sm text-amber-800">
                  <strong>Note:</strong> Staff members can only view and manage their own orders. They cannot see other staff's data or access admin features.
                </p>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 px-4 py-2 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-gradient-to-r from-emerald-500 to-green-600 text-white rounded-lg hover:from-emerald-600 hover:to-green-700"
                >
                  {editingId ? 'Update Staff' : 'Add Staff'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
