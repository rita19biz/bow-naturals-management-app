import { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Building2,
  Phone,
  Mail,
  MapPin,
  DollarSign,
  Percent,
  Save,
  Leaf,
  RefreshCw,
} from 'lucide-react';

export default function CompanySettings() {
  const { companySettings, updateCompanySettings } = useApp();

  const [formData, setFormData] = useState(companySettings);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    setFormData(companySettings);
  }, [companySettings]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateCompanySettings(formData);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleReset = () => {
    setFormData(companySettings);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Company Settings</h1>
          <p className="text-gray-500">Configure your business information</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Settings Form */}
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Company Name
              </label>
              <div className="relative">
                <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  placeholder="Your Company Name"
                />
              </div>
              <p className="text-xs text-gray-400 mt-1">This name will appear throughout the system</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Phone Number
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                    className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                    placeholder="+234 XXX XXX XXXX"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                    placeholder="info@yourcompany.com"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Business Address
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
                <textarea
                  value={formData.address}
                  onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                  className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  rows={2}
                  placeholder="123 Business Street, City, State"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Currency Symbol
                </label>
                <div className="relative">
                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <select
                    value={formData.currency}
                    onChange={(e) => setFormData(prev => ({ ...prev, currency: e.target.value }))}
                    className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="₦">₦ - Nigerian Naira</option>
                    <option value="$">$ - US Dollar</option>
                    <option value="£">£ - British Pound</option>
                    <option value="€">€ - Euro</option>
                    <option value="¢">¢ - Cedi</option>
                    <option value="R">R - South African Rand</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Tax Rate (%)
                </label>
                <div className="relative">
                  <Percent className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="number"
                    min="0"
                    max="100"
                    step="0.1"
                    value={formData.taxRate}
                    onChange={(e) => setFormData(prev => ({ ...prev, taxRate: parseFloat(e.target.value) || 0 }))}
                    className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                    placeholder="7.5"
                  />
                </div>
              </div>
            </div>

            <div className="flex gap-3 pt-4 border-t border-gray-100">
              <button
                type="button"
                onClick={handleReset}
                className="flex items-center gap-2 px-4 py-2 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50"
              >
                <RefreshCw className="w-4 h-4" />
                Reset
              </button>
              <button
                type="submit"
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-500 to-green-600 text-white rounded-lg hover:from-emerald-600 hover:to-green-700"
              >
                <Save className="w-4 h-4" />
                Save Changes
              </button>
            </div>

            {saved && (
              <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-sm text-center">
                Settings saved successfully!
              </div>
            )}
          </form>
        </div>

        {/* Preview Card */}
        <div className="lg:col-span-1">
          <div className="bg-gradient-to-br from-emerald-500 to-green-600 rounded-xl p-6 text-white sticky top-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center">
                <Leaf className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-xl font-bold">{formData.name || 'Company Name'}</h3>
                <p className="text-white/80 text-sm">Business Preview</p>
              </div>
            </div>

            <div className="space-y-4">
              <div className="bg-white/10 rounded-lg p-3">
                <div className="flex items-center gap-2 text-white/70 text-xs mb-1">
                  <Phone className="w-3 h-3" /> Phone
                </div>
                <p className="text-sm">{formData.phone || 'Not set'}</p>
              </div>

              <div className="bg-white/10 rounded-lg p-3">
                <div className="flex items-center gap-2 text-white/70 text-xs mb-1">
                  <Mail className="w-3 h-3" /> Email
                </div>
                <p className="text-sm">{formData.email || 'Not set'}</p>
              </div>

              <div className="bg-white/10 rounded-lg p-3">
                <div className="flex items-center gap-2 text-white/70 text-xs mb-1">
                  <MapPin className="w-3 h-3" /> Address
                </div>
                <p className="text-sm">{formData.address || 'Not set'}</p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="bg-white/10 rounded-lg p-3 text-center">
                  <p className="text-white/70 text-xs mb-1">Currency</p>
                  <p className="text-2xl font-bold">{formData.currency}</p>
                </div>
                <div className="bg-white/10 rounded-lg p-3 text-center">
                  <p className="text-white/70 text-xs mb-1">Tax Rate</p>
                  <p className="text-2xl font-bold">{formData.taxRate}%</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Security Notice */}
      <div className="bg-gray-50 rounded-xl p-6 border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-3">Security & Privacy</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
          <div className="flex gap-3">
            <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-emerald-600">🔒</span>
            </div>
            <div>
              <p className="font-medium text-gray-900">Staff Data Isolation</p>
              <p>Each staff member can only view and manage their own orders</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-blue-600">👁</span>
            </div>
            <div>
              <p className="font-medium text-gray-900">CEO Overview</p>
              <p>Only CEO accounts can view all staff data and summaries</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-purple-600">⚙️</span>
            </div>
            <div>
              <p className="font-medium text-gray-900">Admin-Only Settings</p>
              <p>Products, pricing, and settings can only be modified by CEO</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <span className="text-orange-600">💾</span>
            </div>
            <div>
              <p className="font-medium text-gray-900">Local Storage</p>
              <p>All data is stored securely in your browser's local storage</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
