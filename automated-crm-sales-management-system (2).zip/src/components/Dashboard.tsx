import { useApp } from '../context/AppContext';
import { format, parseISO } from 'date-fns';
import {
  TrendingUp,
  DollarSign,
  Package,
  ShoppingCart,
  AlertTriangle,
  Clock,
  CheckCircle,
  Truck,
  MapPin,
} from 'lucide-react';

export default function Dashboard() {
  const {
    currentUser,
    users,
    products,
    logisticsCompanies,
    getFilteredCRM,
    getProfitAnalytics,
    getFollowUps,
    selectedStaffId,
    setSelectedStaffId,
    companySettings,
  } = useApp();

  const isCEO = currentUser?.role === 'ceo';
  const staffId = isCEO ? selectedStaffId : currentUser?.id;
  
  const staffMembers = users.filter(u => u.role === 'staff');
  const crmEntries = getFilteredCRM(staffId);
  const followUps = getFollowUps(staffId);

  const dailyStats = getProfitAnalytics('daily', staffId);
  const weeklyStats = getProfitAnalytics('weekly', staffId);
  const monthlyStats = getProfitAnalytics('monthly', staffId);
  const yearlyStats = getProfitAnalytics('yearly', staffId);

  const pendingOrders = crmEntries.filter(e => e.status === 'pending').length;
  const processingOrders = crmEntries.filter(e => e.status === 'processing').length;
  const shippedOrders = crmEntries.filter(e => e.status === 'shipped').length;
  const deliveredOrders = crmEntries.filter(e => e.status === 'delivered').length;

  const overdueFollowUps = followUps.filter(f => f.followUpStatus === 'overdue');

  const lowStockProducts = products.filter(p => p.stock <= p.minStock);

  

  const stats = [
    {
      label: 'Total Sales (Month)',
      value: `${companySettings.currency}${monthlyStats.totalSales.toLocaleString()}`,
      change: `${monthlyStats.salesCount} orders`,
      positive: true,
      icon: DollarSign,
      color: 'emerald',
    },
    {
      label: 'Total Orders',
      value: crmEntries.length,
      change: `${deliveredOrders} delivered`,
      positive: true,
      icon: ShoppingCart,
      color: 'blue',
    },
    {
      label: 'Monthly Profit',
      value: `${companySettings.currency}${monthlyStats.totalProfit.toLocaleString()}`,
      change: monthlyStats.totalProfit >= 0 ? 'Profit' : 'Loss',
      positive: monthlyStats.totalProfit >= 0,
      icon: TrendingUp,
      color: 'purple',
    },
    {
      label: 'Follow-ups Due',
      value: followUps.length,
      change: `${overdueFollowUps.length} overdue`,
      positive: overdueFollowUps.length === 0,
      icon: Clock,
      color: 'orange',
    },
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-500">Welcome back, {currentUser?.name}</p>
        </div>

        {isCEO && (
          <div className="flex items-center gap-3">
            <label className="text-sm font-medium text-gray-600">View:</label>
            <select
              value={selectedStaffId}
              onChange={(e) => setSelectedStaffId(e.target.value)}
              className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">All Staff</option>
              {staffMembers.map(staff => (
                <option key={staff.id} value={staff.id}>{staff.name}</option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div key={i} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                  stat.color === 'emerald' ? 'bg-emerald-100' :
                  stat.color === 'blue' ? 'bg-blue-100' :
                  stat.color === 'purple' ? 'bg-purple-100' : 'bg-orange-100'
                }`}>
                  <Icon className={`w-6 h-6 ${
                    stat.color === 'emerald' ? 'text-emerald-600' :
                    stat.color === 'blue' ? 'text-blue-600' :
                    stat.color === 'purple' ? 'text-purple-600' : 'text-orange-600'
                  }`} />
                </div>
                <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                  stat.positive ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                }`}>
                  {stat.change}
                </span>
              </div>
              <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              <p className="text-sm text-gray-500 mt-1">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Quick Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Order Status */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Order Status Overview</h2>
          <div className="space-y-4">
            {[
              { label: 'Pending', count: pendingOrders, color: 'yellow' },
              { label: 'Processing', count: processingOrders, color: 'blue' },
              { label: 'Shipped', count: shippedOrders, color: 'purple' },
              { label: 'Delivered', count: deliveredOrders, color: 'green' },
            ].map((status) => (
              <div key={status.label} className="flex items-center gap-4">
                <div className="w-24 text-sm text-gray-600">{status.label}</div>
                <div className="flex-1 bg-gray-100 rounded-full h-2">
                  <div
                    className={`h-2 rounded-full ${
                      status.color === 'yellow' ? 'bg-yellow-500' :
                      status.color === 'blue' ? 'bg-blue-500' :
                      status.color === 'purple' ? 'bg-purple-500' : 'bg-green-500'
                    }`}
                    style={{ width: `${crmEntries.length > 0 ? (status.count / crmEntries.length) * 100 : 0}%` }}
                  />
                </div>
                <span className="text-sm font-medium text-gray-900 w-8">{status.count}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Profit Summary */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Profit Summary</h2>
          <div className="grid grid-cols-2 gap-4">
            {[
              { label: 'Today', data: dailyStats },
              { label: 'This Week', data: weeklyStats },
              { label: 'This Month', data: monthlyStats },
              { label: 'This Year', data: yearlyStats },
            ].map((period) => (
              <div key={period.label} className="bg-gray-50 rounded-lg p-4">
                <p className="text-xs text-gray-500 uppercase tracking-wide">{period.label}</p>
                <p className={`text-lg font-bold mt-1 ${
                  period.data.totalProfit >= 0 ? 'text-emerald-600' : 'text-red-600'
                }`}>
                  {companySettings.currency}{period.data.totalProfit.toLocaleString()}
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  Sales: {companySettings.currency}{period.data.totalSales.toLocaleString()}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Logistics & Alerts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Follow-ups Due */}
        <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Follow-ups Due</h2>
            <span className="text-xs bg-orange-100 text-orange-600 px-2 py-1 rounded-full">
              {followUps.length} pending
            </span>
          </div>
          {followUps.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <CheckCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
              <p>No follow-ups due</p>
            </div>
          ) : (
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {followUps.slice(0, 5).map((entry) => (
                <div
                  key={entry.id}
                  className={`flex items-center gap-3 p-3 rounded-lg ${
                    entry.followUpStatus === 'overdue' ? 'bg-red-50' : 'bg-orange-50'
                  }`}
                >
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    entry.followUpStatus === 'overdue' ? 'bg-red-100' : 'bg-orange-100'
                  }`}>
                    <Clock className={`w-5 h-5 ${
                      entry.followUpStatus === 'overdue' ? 'text-red-600' : 'text-orange-600'
                    }`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{entry.customerName}</p>
                    <p className="text-xs text-gray-500">
                      Due: {entry.followUpDate ? format(parseISO(entry.followUpDate), 'MMM d, yyyy') : 'N/A'}
                    </p>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    entry.followUpStatus === 'overdue' ? 'bg-red-100 text-red-600' : 'bg-orange-100 text-orange-600'
                  }`}>
                    {entry.followUpStatus}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Logistics Overview (CEO Only) */}
        {isCEO && (
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Logistics Overview</h2>
              <span className="text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded-full">
                {logisticsCompanies.length} locations
              </span>
            </div>
            {logisticsCompanies.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <Truck className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No logistics locations</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {logisticsCompanies.map((company) => {
                  const units = company.inventory.reduce((s, i) => s + i.quantity, 0);
                  return (
                    <div key={company.id} className="flex items-center gap-3 p-3 rounded-lg bg-blue-50">
                      <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                        <MapPin className="w-5 h-5 text-blue-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 truncate">{company.name}</p>
                        <p className="text-xs text-gray-500">{company.inventory.length} products</p>
                      </div>
                      <span className="text-sm font-bold text-blue-600">
                        {units} units
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Low Stock Alert */}
        {isCEO && (
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Low Stock Alert</h2>
              <span className="text-xs bg-red-100 text-red-600 px-2 py-1 rounded-full">
                {lowStockProducts.length} items
              </span>
            </div>
            {lowStockProducts.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <Package className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>All products well stocked</p>
              </div>
            ) : (
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {lowStockProducts.map((product) => (
                  <div key={product.id} className="flex items-center gap-3 p-3 rounded-lg bg-red-50">
                    <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center">
                      <AlertTriangle className="w-5 h-5 text-red-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">{product.name}</p>
                      <p className="text-xs text-gray-500">SKU: {product.sku}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-red-600">{product.stock}</p>
                      <p className="text-xs text-gray-400">Min: {product.minStock}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
