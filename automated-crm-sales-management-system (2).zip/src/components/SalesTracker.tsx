import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { format, parseISO, startOfDay, endOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth, startOfYear, endOfYear, subDays, subWeeks, subMonths } from 'date-fns';
import { OrderType } from '../types';
import {
  Search,
  TrendingUp,
  DollarSign,
  Package,
  Calendar,
  Eye,
  X,
  Truck,
} from 'lucide-react';

type DateFilterType = 'today' | 'yesterday' | 'this_week' | 'last_week' | 'this_month' | 'last_month' | 'this_year' | 'custom';

export default function SalesTracker() {
  const {
    currentUser,
    users,
    getFilteredSales,
    selectedStaffId,
    setSelectedStaffId,
    companySettings,
  } = useApp();

  const isCEO = currentUser?.role === 'ceo';
  const staffId = isCEO ? selectedStaffId : currentUser?.id;
  const staffMembers = users.filter(u => u.role === 'staff');

  const [searchTerm, setSearchTerm] = useState('');
  const [dateFilter, setDateFilter] = useState<DateFilterType>('this_month');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  const [orderTypeFilter, setOrderTypeFilter] = useState<string>('all');
  const [viewingEntry, setViewingEntry] = useState<string | null>(null);

  const getDateRange = () => {
    const now = new Date();
    switch (dateFilter) {
      case 'today':
        return { start: startOfDay(now), end: endOfDay(now) };
      case 'yesterday':
        const yesterday = subDays(now, 1);
        return { start: startOfDay(yesterday), end: endOfDay(yesterday) };
      case 'this_week':
        return { start: startOfWeek(now, { weekStartsOn: 1 }), end: endOfWeek(now, { weekStartsOn: 1 }) };
      case 'last_week':
        const lastWeek = subWeeks(now, 1);
        return { start: startOfWeek(lastWeek, { weekStartsOn: 1 }), end: endOfWeek(lastWeek, { weekStartsOn: 1 }) };
      case 'this_month':
        return { start: startOfMonth(now), end: endOfMonth(now) };
      case 'last_month':
        const lastMonth = subMonths(now, 1);
        return { start: startOfMonth(lastMonth), end: endOfMonth(lastMonth) };
      case 'this_year':
        return { start: startOfYear(now), end: endOfYear(now) };
      case 'custom':
        if (customStartDate && customEndDate) {
          return { 
            start: startOfDay(parseISO(customStartDate)), 
            end: endOfDay(parseISO(customEndDate)) 
          };
        }
        return undefined;
      default:
        return undefined;
    }
  };

  const dateRange = getDateRange();
  const salesEntries = getFilteredSales(staffId, dateRange);

  const filteredEntries = salesEntries.filter(entry => {
    const matchesSearch = entry.customerName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesOrderType = orderTypeFilter === 'all' || entry.orderType === orderTypeFilter;
    return matchesSearch && matchesOrderType;
  });

  // Calculate stats
  const totalSales = filteredEntries.reduce((sum, s) => sum + s.totalAmount, 0);
  const totalDeliveryCost = filteredEntries.reduce((sum, s) => sum + (s.deliveryCost || 0), 0);
  const totalCost = filteredEntries.reduce((sum, s) => sum + s.costAmount, 0);
  const totalProfit = filteredEntries.reduce((sum, s) => sum + s.profit, 0);
  const profitMargin = totalSales > 0 ? (totalProfit / totalSales) * 100 : 0;

  // Stats by order type
  const retailSales = filteredEntries.filter(s => s.orderType === 'retail');
  const wholesaleSales = filteredEntries.filter(s => s.orderType === 'wholesale');
  const dmGroupSales = filteredEntries.filter(s => s.orderType === 'dm_group');

  const getOrderTypeLabel = (type: OrderType) => {
    switch (type) {
      case 'retail': return 'Retail';
      case 'wholesale': return 'Wholesale';
      case 'dm_group': return 'DM/Group';
    }
  };

  const getOrderTypeColor = (type: OrderType) => {
    switch (type) {
      case 'retail': return 'bg-blue-100 text-blue-700';
      case 'wholesale': return 'bg-purple-100 text-purple-700';
      case 'dm_group': return 'bg-orange-100 text-orange-700';
    }
  };

  const viewEntry = salesEntries.find(e => e.id === viewingEntry);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Sales Tracker</h1>
          <p className="text-gray-500">Auto-tracked from delivered CRM orders</p>
        </div>
        {isCEO && (
          <select
            value={selectedStaffId}
            onChange={(e) => setSelectedStaffId(e.target.value)}
            className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">All Staff</option>
            {staffMembers.map(staff => (
              <option key={staff.id} value={staff.id}>{staff.name}</option>
            ))}
          </select>
        )}
      </div>

      {/* Date Filter */}
      <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
        <div className="flex flex-wrap gap-2 mb-3">
          {([
            { key: 'today', label: 'Today' },
            { key: 'yesterday', label: 'Yesterday' },
            { key: 'this_week', label: 'This Week' },
            { key: 'last_week', label: 'Last Week' },
            { key: 'this_month', label: 'This Month' },
            { key: 'last_month', label: 'Last Month' },
            { key: 'this_year', label: 'This Year' },
            { key: 'custom', label: 'Custom' },
          ] as { key: DateFilterType; label: string }[]).map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setDateFilter(key)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                dateFilter === key
                  ? 'bg-emerald-500 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
        {dateFilter === 'custom' && (
          <div className="flex gap-4 items-center">
            <input
              type="date"
              value={customStartDate}
              onChange={(e) => setCustomStartDate(e.target.value)}
              className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
            />
            <span className="text-gray-400">to</span>
            <input
              type="date"
              value={customEndDate}
              onChange={(e) => setCustomEndDate(e.target.value)}
              className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        )}
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Total Sales</p>
              <p className="text-xl font-bold text-gray-900">
                {companySettings.currency}{totalSales.toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <Truck className="w-5 h-5 text-orange-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Delivery Cost</p>
              <p className="text-xl font-bold text-orange-600">
                {companySettings.currency}{totalDeliveryCost.toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Package className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Product Cost</p>
              <p className="text-xl font-bold text-gray-900">
                {companySettings.currency}{totalCost.toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Net Profit</p>
              <p className={`text-xl font-bold ${totalProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {companySettings.currency}{totalProfit.toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Profit Margin</p>
              <p className="text-xl font-bold text-gray-900">
                {profitMargin.toFixed(1)}%
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Order Type Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-blue-50 rounded-xl p-4 border border-blue-100">
          <p className="text-sm text-blue-600 font-medium">Retail Sales</p>
          <p className="text-2xl font-bold text-blue-700">
            {companySettings.currency}{retailSales.reduce((s, e) => s + e.totalAmount, 0).toLocaleString()}
          </p>
          <p className="text-xs text-blue-500 mt-1">{retailSales.length} orders</p>
        </div>
        <div className="bg-purple-50 rounded-xl p-4 border border-purple-100">
          <p className="text-sm text-purple-600 font-medium">Wholesale Sales</p>
          <p className="text-2xl font-bold text-purple-700">
            {companySettings.currency}{wholesaleSales.reduce((s, e) => s + e.totalAmount, 0).toLocaleString()}
          </p>
          <p className="text-xs text-purple-500 mt-1">{wholesaleSales.length} orders</p>
        </div>
        <div className="bg-orange-50 rounded-xl p-4 border border-orange-100">
          <p className="text-sm text-orange-600 font-medium">DM/Group Sales</p>
          <p className="text-2xl font-bold text-orange-700">
            {companySettings.currency}{dmGroupSales.reduce((s, e) => s + e.totalAmount, 0).toLocaleString()}
          </p>
          <p className="text-xs text-orange-500 mt-1">{dmGroupSales.length} orders</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <div className="flex-1 min-w-[200px] relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search by customer name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
          />
        </div>
        <select
          value={orderTypeFilter}
          onChange={(e) => setOrderTypeFilter(e.target.value)}
          className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
        >
          <option value="all">All Order Types</option>
          <option value="retail">Retail</option>
          <option value="wholesale">Wholesale</option>
          <option value="dm_group">DM/Group</option>
        </select>
      </div>

      {/* Sales Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Date</th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Customer</th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Type</th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Products</th>
                <th className="text-right px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Sales</th>
                <th className="text-right px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Delivery</th>
                <th className="text-right px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Cost</th>
                <th className="text-right px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Profit</th>
                <th className="text-center px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredEntries.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-6 py-12 text-center text-gray-400">
                    No sales records found for this period
                  </td>
                </tr>
              ) : (
                filteredEntries.map((entry) => (
                  <tr key={entry.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 text-sm text-gray-900">
                      {format(parseISO(entry.saleDate), 'MMM d, yyyy')}
                    </td>
                    <td className="px-6 py-4">
                      <p className="font-medium text-gray-900">{entry.customerName}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${getOrderTypeColor(entry.orderType)}`}>
                        {getOrderTypeLabel(entry.orderType)}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600">
                      {entry.products.length} item(s)
                    </td>
                    <td className="px-6 py-4 text-sm font-semibold text-gray-900 text-right">
                      {companySettings.currency}{entry.totalAmount.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-sm text-orange-600 text-right">
                      {companySettings.currency}{(entry.deliveryCost || 0).toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-600 text-right">
                      {companySettings.currency}{entry.costAmount.toLocaleString()}
                    </td>
                    <td className={`px-6 py-4 text-sm font-semibold text-right ${
                      entry.profit >= 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {companySettings.currency}{entry.profit.toLocaleString()}
                    </td>
                    <td className="px-6 py-4 text-center">
                      <button
                        onClick={() => setViewingEntry(entry.id)}
                        className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            {filteredEntries.length > 0 && (
              <tfoot className="bg-gray-50 font-semibold">
                <tr>
                  <td colSpan={4} className="px-6 py-4 text-sm text-gray-700">
                    Total ({filteredEntries.length} sales)
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-900 text-right">
                    {companySettings.currency}{totalSales.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-sm text-orange-600 text-right">
                    {companySettings.currency}{totalDeliveryCost.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-600 text-right">
                    {companySettings.currency}{totalCost.toLocaleString()}
                  </td>
                  <td className={`px-6 py-4 text-sm text-right ${totalProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {companySettings.currency}{totalProfit.toLocaleString()}
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

      {/* View Sale Modal */}
      {viewEntry && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-xl shadow-xl">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">Sale Details</h3>
              <button
                onClick={() => setViewingEntry(null)}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-500">Sale Date</p>
                  <p className="font-medium text-gray-900">
                    {format(parseISO(viewEntry.saleDate), 'MMM d, yyyy')}
                  </p>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-500">Customer</p>
                  <p className="font-medium text-gray-900">{viewEntry.customerName}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-500">Order Type</p>
                  <span className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${getOrderTypeColor(viewEntry.orderType)}`}>
                    {getOrderTypeLabel(viewEntry.orderType)}
                  </span>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-500">Source</p>
                  <p className="font-medium text-gray-900">
                    {viewEntry.crmId ? 'CRM Order' : 'Manual Entry'}
                  </p>
                </div>
              </div>

              <div>
                <h4 className="font-medium text-gray-900 mb-3">Products</h4>
                <div className="border border-gray-200 rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left px-4 py-2 text-xs font-medium text-gray-500">Product</th>
                        <th className="text-center px-4 py-2 text-xs font-medium text-gray-500">Qty</th>
                        <th className="text-right px-4 py-2 text-xs font-medium text-gray-500">Price</th>
                        <th className="text-right px-4 py-2 text-xs font-medium text-gray-500">Cost</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {viewEntry.products.map((p, i) => (
                        <tr key={i}>
                          <td className="px-4 py-3 text-sm text-gray-900">{p.productName}</td>
                          <td className="px-4 py-3 text-sm text-gray-600 text-center">{p.quantity}</td>
                          <td className="px-4 py-3 text-sm font-medium text-gray-900 text-right">
                            {companySettings.currency}{p.total.toLocaleString()}
                          </td>
                          <td className="px-4 py-3 text-sm text-gray-600 text-right">
                            {companySettings.currency}{(p.costPrice * p.quantity).toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-gray-100">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Sales Total</span>
                    <span className="text-sm font-medium text-gray-900">
                      {companySettings.currency}{viewEntry.totalAmount.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Delivery Cost</span>
                    <span className="text-sm font-medium text-orange-600">
                      -{companySettings.currency}{(viewEntry.deliveryCost || 0).toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-500">Product Cost</span>
                    <span className="text-sm font-medium text-gray-600">
                      -{companySettings.currency}{viewEntry.costAmount.toLocaleString()}
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-sm text-gray-500">Net Profit</p>
                    <p className={`text-2xl font-bold ${viewEntry.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {companySettings.currency}{viewEntry.profit.toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
