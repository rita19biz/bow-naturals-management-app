import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { format, parseISO, startOfYear, eachDayOfInterval, eachWeekOfInterval, eachMonthOfInterval, isSameDay, isSameWeek, isSameMonth, subDays, subWeeks, subMonths, startOfDay, endOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth, endOfYear } from 'date-fns';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  Legend,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  Calendar,
  Download,
} from 'lucide-react';

const COLORS = ['#10b981', '#ef4444', '#3b82f6', '#8b5cf6', '#f59e0b', '#ec4899'];

type DateFilterType = 'today' | 'yesterday' | 'this_week' | 'last_week' | 'this_month' | 'last_month' | 'this_year' | 'custom';

export default function ProfitAnalytics() {
  const {
    currentUser,
    users,
    getFilteredSales,
    getFilteredExpenses,
    getProfitAnalytics,
    selectedStaffId,
    setSelectedStaffId,
    companySettings,
  } = useApp();

  const isCEO = currentUser?.role === 'ceo';
  const staffId = isCEO ? selectedStaffId : currentUser?.id;
  const staffMembers = users.filter(u => u.role === 'staff');

  const [dateFilter, setDateFilter] = useState<DateFilterType>('this_month');
  const [customStartDate, setCustomStartDate] = useState('');
  const [customEndDate, setCustomEndDate] = useState('');
  const [chartView, setChartView] = useState<'daily' | 'weekly' | 'monthly'>('daily');

  const getDateRange = () => {
    const now = new Date();
    switch (dateFilter) {
      case 'today':
        return { start: startOfDay(now), end: endOfDay(now) };
      case 'yesterday':
        const yesterday = subDays(now, 1);
        return { start: startOfDay(yesterday), end: endOfDay(yesterday) };
      case 'this_week':
        return { start: startOfWeek(now, { weekStartsOn: 1 }), end: endOfWeek(now, { weekStartsOn: 1 }) };
      case 'last_week':
        const lastWeek = subWeeks(now, 1);
        return { start: startOfWeek(lastWeek, { weekStartsOn: 1 }), end: endOfWeek(lastWeek, { weekStartsOn: 1 }) };
      case 'this_month':
        return { start: startOfMonth(now), end: endOfMonth(now) };
      case 'last_month':
        const lastMonth = subMonths(now, 1);
        return { start: startOfMonth(lastMonth), end: endOfMonth(lastMonth) };
      case 'this_year':
        return { start: startOfYear(now), end: endOfYear(now) };
      case 'custom':
        if (customStartDate && customEndDate) {
          return { 
            start: startOfDay(parseISO(customStartDate)), 
            end: endOfDay(parseISO(customEndDate)) 
          };
        }
        return { start: startOfMonth(now), end: endOfMonth(now) };
      default:
        return { start: startOfMonth(now), end: endOfMonth(now) };
    }
  };

  const dateRange = getDateRange();
  
  const dailyStats = getProfitAnalytics('daily', staffId);
  const weeklyStats = getProfitAnalytics('weekly', staffId);
  const monthlyStats = getProfitAnalytics('monthly', staffId);
  const yearlyStats = getProfitAnalytics('yearly', staffId);
  const customStats = getProfitAnalytics('custom', staffId, dateRange);

  const sales = getFilteredSales(staffId, dateRange);
  const expenses = getFilteredExpenses(staffId, dateRange);

  // Generate chart data based on view
  const generateChartData = () => {
    let dates: Date[] = [];
    let formatStr = '';

    switch (chartView) {
      case 'daily':
        dates = eachDayOfInterval({ start: dateRange.start, end: dateRange.end });
        formatStr = 'MMM d';
        break;
      case 'weekly':
        dates = eachWeekOfInterval({ start: dateRange.start, end: dateRange.end }, { weekStartsOn: 1 });
        formatStr = 'MMM d';
        break;
      case 'monthly':
        dates = eachMonthOfInterval({ start: dateRange.start, end: dateRange.end });
        formatStr = 'MMM yyyy';
        break;
    }

    return dates.map(date => {
      const periodSales = sales.filter(s => {
        const saleDate = parseISO(s.saleDate);
        if (chartView === 'daily') return isSameDay(saleDate, date);
        if (chartView === 'weekly') return isSameWeek(saleDate, date, { weekStartsOn: 1 });
        return isSameMonth(saleDate, date);
      });

      const periodExpenses = expenses.filter(e => {
        const expenseDate = parseISO(e.date);
        if (chartView === 'daily') return isSameDay(expenseDate, date);
        if (chartView === 'weekly') return isSameWeek(expenseDate, date, { weekStartsOn: 1 });
        return isSameMonth(expenseDate, date);
      });

      const totalSales = periodSales.reduce((sum, s) => sum + s.totalAmount, 0);
      const totalDeliveryCost = periodSales.reduce((sum, s) => sum + (s.deliveryCost || 0), 0);
      const totalCost = periodSales.reduce((sum, s) => sum + s.costAmount, 0);
      const totalExpenses = periodExpenses.reduce((sum, e) => sum + e.amount, 0);
      const profit = totalSales - totalDeliveryCost - totalCost - totalExpenses;

      return {
        date: format(date, formatStr),
        sales: totalSales,
        deliveryCost: totalDeliveryCost,
        expenses: totalExpenses + totalCost,
        profit,
      };
    });
  };

  const chartData = generateChartData();

  // Category breakdown for expenses
  const expenseCategories = expenses.reduce((acc, e) => {
    acc[e.category] = (acc[e.category] || 0) + e.amount;
    return acc;
  }, {} as Record<string, number>);

  const categoryChartData = Object.entries(expenseCategories).map(([name, value]) => ({
    name,
    value,
  }));

  // Order type breakdown
  const orderTypeData = [
    { name: 'Retail', value: sales.filter(s => s.orderType === 'retail').reduce((sum, s) => sum + s.totalAmount, 0), profit: sales.filter(s => s.orderType === 'retail').reduce((sum, s) => sum + s.profit, 0) },
    { name: 'Wholesale', value: sales.filter(s => s.orderType === 'wholesale').reduce((sum, s) => sum + s.totalAmount, 0), profit: sales.filter(s => s.orderType === 'wholesale').reduce((sum, s) => sum + s.profit, 0) },
    { name: 'DM/Group', value: sales.filter(s => s.orderType === 'dm_group').reduce((sum, s) => sum + s.totalAmount, 0), profit: sales.filter(s => s.orderType === 'dm_group').reduce((sum, s) => sum + s.profit, 0) },
  ].filter(d => d.value > 0);

  // Staff performance (CEO only)
  const staffPerformance = isCEO ? staffMembers.map(staff => {
    const staffSales = getFilteredSales(staff.id, dateRange);
    const totalSales = staffSales.reduce((sum, s) => sum + s.totalAmount, 0);
    const totalProfit = staffSales.reduce((sum, s) => sum + s.profit, 0);
    return {
      name: staff.name,
      sales: totalSales,
      profit: totalProfit,
    };
  }) : [];

  const exportData = () => {
    const data = {
      dateRange: {
        start: format(dateRange.start, 'yyyy-MM-dd'),
        end: format(dateRange.end, 'yyyy-MM-dd'),
      },
      generatedAt: new Date().toISOString(),
      summary: customStats,
      quickStats: {
        daily: dailyStats,
        weekly: weeklyStats,
        monthly: monthlyStats,
        yearly: yearlyStats,
      },
      chartData,
      expenseCategories: categoryChartData,
      orderTypeBreakdown: orderTypeData,
      staffPerformance,
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `profit-report-${format(new Date(), 'yyyy-MM-dd')}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Profit Analytics</h1>
          <p className="text-gray-500">Comprehensive profit and loss overview</p>
        </div>
        <div className="flex items-center gap-3">
          {isCEO && (
            <select
              value={selectedStaffId}
              onChange={(e) => setSelectedStaffId(e.target.value)}
              className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">All Staff</option>
              {staffMembers.map(staff => (
                <option key={staff.id} value={staff.id}>{staff.name}</option>
              ))}
            </select>
          )}
          <button
            onClick={exportData}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition"
          >
            <Download className="w-5 h-5" />
            Export
          </button>
        </div>
      </div>

      {/* Quick Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-emerald-500 to-green-600 rounded-xl p-5 text-white">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5" />
            </div>
            <span className="text-xs bg-white/20 px-2 py-1 rounded-full">Today</span>
          </div>
          <p className="text-2xl font-bold">{companySettings.currency}{dailyStats.totalProfit.toLocaleString()}</p>
          <p className="text-sm text-white/80 mt-1">Daily Profit</p>
        </div>

        <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl p-5 text-white">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5" />
            </div>
            <span className="text-xs bg-white/20 px-2 py-1 rounded-full">This Week</span>
          </div>
          <p className="text-2xl font-bold">{companySettings.currency}{weeklyStats.totalProfit.toLocaleString()}</p>
          <p className="text-sm text-white/80 mt-1">Weekly Profit</p>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-violet-600 rounded-xl p-5 text-white">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5" />
            </div>
            <span className="text-xs bg-white/20 px-2 py-1 rounded-full">This Month</span>
          </div>
          <p className="text-2xl font-bold">{companySettings.currency}{monthlyStats.totalProfit.toLocaleString()}</p>
          <p className="text-sm text-white/80 mt-1">Monthly Profit</p>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-amber-600 rounded-xl p-5 text-white">
          <div className="flex items-center justify-between mb-3">
            <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5" />
            </div>
            <span className="text-xs bg-white/20 px-2 py-1 rounded-full">This Year</span>
          </div>
          <p className="text-2xl font-bold">{companySettings.currency}{yearlyStats.totalProfit.toLocaleString()}</p>
          <p className="text-sm text-white/80 mt-1">Yearly Profit</p>
        </div>
      </div>

      {/* Date Filter */}
      <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
        <p className="text-sm font-medium text-gray-700 mb-3">Select Period for Analysis</p>
        <div className="flex flex-wrap gap-2 mb-3">
          {([
            { key: 'today', label: 'Today' },
            { key: 'yesterday', label: 'Yesterday' },
            { key: 'this_week', label: 'This Week' },
            { key: 'last_week', label: 'Last Week' },
            { key: 'this_month', label: 'This Month' },
            { key: 'last_month', label: 'Last Month' },
            { key: 'this_year', label: 'This Year' },
            { key: 'custom', label: 'Custom' },
          ] as { key: DateFilterType; label: string }[]).map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setDateFilter(key)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                dateFilter === key
                  ? 'bg-emerald-500 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
        {dateFilter === 'custom' && (
          <div className="flex gap-4 items-center">
            <input
              type="date"
              value={customStartDate}
              onChange={(e) => setCustomStartDate(e.target.value)}
              className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
            />
            <span className="text-gray-400">to</span>
            <input
              type="date"
              value={customEndDate}
              onChange={(e) => setCustomEndDate(e.target.value)}
              className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
            />
          </div>
        )}
      </div>

      {/* Period Summary */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-4">Period Summary</h3>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          <div className="bg-emerald-50 rounded-lg p-4 text-center">
            <p className="text-xs text-emerald-600 uppercase tracking-wide">Sales</p>
            <p className="text-2xl font-bold text-emerald-700">
              {companySettings.currency}{customStats.totalSales.toLocaleString()}
            </p>
          </div>
          <div className="bg-orange-50 rounded-lg p-4 text-center">
            <p className="text-xs text-orange-600 uppercase tracking-wide">Delivery Cost</p>
            <p className="text-2xl font-bold text-orange-700">
              {companySettings.currency}{customStats.totalDeliveryCost.toLocaleString()}
            </p>
          </div>
          <div className="bg-red-50 rounded-lg p-4 text-center">
            <p className="text-xs text-red-600 uppercase tracking-wide">Expenses</p>
            <p className="text-2xl font-bold text-red-700">
              {companySettings.currency}{customStats.totalExpenses.toLocaleString()}
            </p>
          </div>
          <div className={`rounded-lg p-4 text-center ${customStats.totalProfit >= 0 ? 'bg-green-50' : 'bg-red-50'}`}>
            <p className={`text-xs uppercase tracking-wide ${customStats.totalProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
              Net Profit
            </p>
            <p className={`text-2xl font-bold ${customStats.totalProfit >= 0 ? 'text-green-700' : 'text-red-700'}`}>
              {companySettings.currency}{customStats.totalProfit.toLocaleString()}
            </p>
          </div>
          <div className="bg-blue-50 rounded-lg p-4 text-center">
            <p className="text-xs text-blue-600 uppercase tracking-wide">Orders</p>
            <p className="text-2xl font-bold text-blue-700">
              {customStats.salesCount}
            </p>
          </div>
        </div>
      </div>

      {/* Chart View Selector */}
      <div className="flex gap-2">
        {(['daily', 'weekly', 'monthly'] as const).map((view) => (
          <button
            key={view}
            onClick={() => setChartView(view)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
              chartView === view
                ? 'bg-emerald-500 text-white'
                : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {view.charAt(0).toUpperCase() + view.slice(1)}
          </button>
        ))}
      </div>

      {/* Main Chart */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-4">Revenue, Expenses & Profit Trend</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="date" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Legend />
              <Area
                type="monotone"
                dataKey="sales"
                name="Sales"
                stackId="1"
                stroke="#10b981"
                fill="#10b98133"
              />
              <Area
                type="monotone"
                dataKey="expenses"
                name="Costs & Expenses"
                stackId="2"
                stroke="#ef4444"
                fill="#ef444433"
              />
              <Area
                type="monotone"
                dataKey="profit"
                name="Profit"
                stackId="3"
                stroke="#3b82f6"
                fill="#3b82f633"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Order Type Breakdown */}
        {orderTypeData.length > 0 && (
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <h3 className="font-semibold text-gray-900 mb-4">Sales by Order Type</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={orderTypeData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis type="number" tick={{ fontSize: 12 }} />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 12 }} width={80} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="value" name="Sales" fill="#10b981" radius={[0, 4, 4, 0]} />
                  <Bar dataKey="profit" name="Profit" fill="#3b82f6" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Expense Categories Pie Chart */}
        {categoryChartData.length > 0 && (
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <h3 className="font-semibold text-gray-900 mb-4">Expense Distribution</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryChartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${((percent || 0) * 100).toFixed(0)}%`}
                  >
                    {categoryChartData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Staff Performance (CEO Only) */}
        {isCEO && staffPerformance.length > 0 && (
          <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 lg:col-span-2">
            <h3 className="font-semibold text-gray-900 mb-4">Staff Performance</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={staffPerformance}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="sales" name="Sales" fill="#10b981" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="profit" name="Profit" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </div>

      {/* Detailed Summary Table */}
      <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
        <h3 className="font-semibold text-gray-900 mb-4">Quick Summary Comparison</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Period</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Sales</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Delivery</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Expenses</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Profit</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500 uppercase">Margin</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {[
                { name: 'Today', data: dailyStats },
                { name: 'This Week', data: weeklyStats },
                { name: 'This Month', data: monthlyStats },
                { name: 'This Year', data: yearlyStats },
              ].map(({ name, data }) => {
                const margin = data.totalSales > 0 ? (data.totalProfit / data.totalSales) * 100 : 0;
                return (
                  <tr key={name} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900">{name}</td>
                    <td className="px-4 py-3 text-right text-emerald-600 font-medium">
                      {companySettings.currency}{data.totalSales.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-right text-orange-600 font-medium">
                      {companySettings.currency}{data.totalDeliveryCost.toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-right text-red-600 font-medium">
                      {companySettings.currency}{data.totalExpenses.toLocaleString()}
                    </td>
                    <td className={`px-4 py-3 text-right font-bold ${
                      data.totalProfit >= 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {companySettings.currency}{data.totalProfit.toLocaleString()}
                    </td>
                    <td className={`px-4 py-3 text-right font-medium ${
                      margin >= 0 ? 'text-blue-600' : 'text-red-600'
                    }`}>
                      {margin.toFixed(1)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
