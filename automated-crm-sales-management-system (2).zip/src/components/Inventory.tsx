import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { PriceTier, OrderType, OrderTypePricing } from '../types';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  X,
  Package,
  AlertTriangle,
  DollarSign,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

const CATEGORIES = [
  'Hair Care',
  'Skin Care',
  'Body Care',
  'Oils',
  'Butters',
  'Creams',
  'Lotions',
  'Soaps',
  'Other',
];

const ORDER_TYPES: { key: OrderType; label: string }[] = [
  { key: 'retail', label: 'Retail' },
  { key: 'wholesale', label: 'Wholesale' },
  { key: 'dm_group', label: 'DM/Group' },
];

export default function Inventory() {
  const {
    products,
    addProduct,
    updateProduct,
    deleteProduct,
    companySettings,
  } = useApp();

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [expandedProduct, setExpandedProduct] = useState<string | null>(null);

  const defaultPricing: OrderTypePricing = {
    retail: [{ minQuantity: 1, maxQuantity: null, price: 0 }],
    wholesale: [{ minQuantity: 1, maxQuantity: null, price: 0 }],
    dm_group: [{ minQuantity: 1, maxQuantity: null, price: 0 }],
  };

  const [formData, setFormData] = useState({
    name: '',
    sku: '',
    category: '',
    description: '',
    pricing: defaultPricing,
    costPrice: '',
    stock: '',
    minStock: '',
    unit: 'piece',
  });

  const [activeTab, setActiveTab] = useState<OrderType>('retail');

  const resetForm = () => {
    setFormData({
      name: '',
      sku: '',
      category: '',
      description: '',
      pricing: defaultPricing,
      costPrice: '',
      stock: '',
      minStock: '',
      unit: 'piece',
    });
    setEditingId(null);
    setShowForm(false);
    setActiveTab('retail');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const productData = {
      name: formData.name,
      sku: formData.sku,
      category: formData.category,
      description: formData.description,
      pricing: formData.pricing,
      costPrice: parseFloat(formData.costPrice) || 0,
      stock: parseInt(formData.stock) || 0,
      minStock: parseInt(formData.minStock) || 0,
      unit: formData.unit,
    };

    if (editingId) {
      updateProduct(editingId, productData);
    } else {
      addProduct(productData);
    }
    resetForm();
  };

  const handleEdit = (product: typeof products[0]) => {
    setFormData({
      name: product.name,
      sku: product.sku,
      category: product.category,
      description: product.description,
      pricing: product.pricing || defaultPricing,
      costPrice: product.costPrice.toString(),
      stock: product.stock.toString(),
      minStock: product.minStock.toString(),
      unit: product.unit,
    });
    setEditingId(product.id);
    setShowForm(true);
  };

  const addPriceTier = (orderType: OrderType) => {
    const tiers = formData.pricing[orderType];
    const lastTier = tiers[tiers.length - 1];
    setFormData(prev => ({
      ...prev,
      pricing: {
        ...prev.pricing,
        [orderType]: [
          ...prev.pricing[orderType],
          { minQuantity: (lastTier?.maxQuantity || lastTier?.minQuantity || 0) + 1, maxQuantity: null, price: 0 },
        ],
      },
    }));
  };

  const removePriceTier = (orderType: OrderType, index: number) => {
    if (formData.pricing[orderType].length > 1) {
      setFormData(prev => ({
        ...prev,
        pricing: {
          ...prev.pricing,
          [orderType]: prev.pricing[orderType].filter((_, i) => i !== index),
        },
      }));
    }
  };

  const updatePriceTier = (orderType: OrderType, index: number, field: keyof PriceTier, value: number | null) => {
    setFormData(prev => ({
      ...prev,
      pricing: {
        ...prev.pricing,
        [orderType]: prev.pricing[orderType].map((tier, i) =>
          i === index ? { ...tier, [field]: value } : tier
        ),
      },
    }));
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         product.sku.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = categoryFilter === 'all' || product.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const lowStockProducts = products.filter(p => p.stock <= p.minStock);
  const totalValue = products.reduce((sum, p) => sum + (p.costPrice * p.stock), 0);

  const getOrderTypeLabel = (type: OrderType) => {
    switch (type) {
      case 'retail': return 'Retail';
      case 'wholesale': return 'Wholesale';
      case 'dm_group': return 'DM/Group';
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Inventory Management</h1>
          <p className="text-gray-500">Manage products with order-type based pricing</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-500 to-green-600 text-white rounded-lg hover:from-emerald-600 hover:to-green-700 transition shadow-lg shadow-emerald-200"
        >
          <Plus className="w-5 h-5" />
          Add Product
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Package className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Total Products</p>
              <p className="text-xl font-bold text-gray-900">{products.length}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">Total Inventory Value</p>
              <p className="text-xl font-bold text-gray-900">
                {companySettings.currency}{totalValue.toLocaleString()}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
              lowStockProducts.length > 0 ? 'bg-red-100' : 'bg-green-100'
            }`}>
              <AlertTriangle className={`w-5 h-5 ${
                lowStockProducts.length > 0 ? 'text-red-600' : 'text-green-600'
              }`} />
            </div>
            <div>
              <p className="text-sm text-gray-500">Low Stock Items</p>
              <p className={`text-xl font-bold ${
                lowStockProducts.length > 0 ? 'text-red-600' : 'text-green-600'
              }`}>
                {lowStockProducts.length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <div className="flex-1 min-w-[200px] relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search by name or SKU..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
          />
        </div>
        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
        >
          <option value="all">All Categories</option>
          {CATEGORIES.map(cat => (
            <option key={cat} value={cat}>{cat}</option>
          ))}
        </select>
      </div>

      {/* Products List */}
      <div className="space-y-4">
        {filteredProducts.length === 0 ? (
          <div className="bg-white rounded-xl p-12 text-center text-gray-400 shadow-sm border border-gray-100">
            <Package className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No products found</p>
          </div>
        ) : (
          filteredProducts.map((product) => (
            <div key={product.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <div 
                className="p-5 cursor-pointer hover:bg-gray-50 transition"
                onClick={() => setExpandedProduct(expandedProduct === product.id ? null : product.id)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                      <Package className="w-6 h-6 text-emerald-600" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold text-gray-900">{product.name}</h3>
                        <span className="px-2 py-0.5 bg-gray-100 rounded-full text-xs text-gray-600">
                          {product.category}
                        </span>
                      </div>
                      <p className="text-sm text-gray-500">SKU: {product.sku}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <p className={`text-lg font-bold ${
                        product.stock <= product.minStock ? 'text-red-600' : 'text-gray-900'
                      }`}>
                        {product.stock} {product.unit}s
                      </p>
                      <p className="text-xs text-gray-500">
                        Cost: {companySettings.currency}{product.costPrice.toLocaleString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleEdit(product);
                        }}
                        className="p-2 text-gray-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm('Are you sure you want to delete this product?')) {
                            deleteProduct(product.id);
                          }
                        }}
                        className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                      {expandedProduct === product.id ? (
                        <ChevronUp className="w-5 h-5 text-gray-400" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-gray-400" />
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Expanded Pricing Details */}
              {expandedProduct === product.id && (
                <div className="px-5 pb-5 border-t border-gray-100">
                  <div className="pt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                    {ORDER_TYPES.map(({ key, label }) => (
                      <div key={key} className="bg-gray-50 rounded-lg p-4">
                        <h4 className="font-medium text-gray-900 mb-3">{label} Pricing</h4>
                        <div className="space-y-2">
                          {(product.pricing?.[key] || []).map((tier, i) => (
                            <div key={i} className="flex justify-between text-sm">
                              <span className="text-gray-600">
                                {tier.maxQuantity 
                                  ? `${tier.minQuantity} - ${tier.maxQuantity}`
                                  : `${tier.minQuantity}+`}
                              </span>
                              <span className="font-medium text-emerald-600">
                                {companySettings.currency}{tier.price.toLocaleString()}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                  {product.description && (
                    <p className="text-sm text-gray-500 mt-4">{product.description}</p>
                  )}
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Add/Edit Product Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-3xl shadow-xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between sticky top-0 bg-white z-10">
              <h3 className="text-lg font-semibold text-gray-900">
                {editingId ? 'Edit Product' : 'Add Product'}
              </h3>
              <button
                onClick={resetForm}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Product Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    SKU *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.sku}
                    onChange={(e) => setFormData(prev => ({ ...prev, sku: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Category *
                  </label>
                  <select
                    required
                    value={formData.category}
                    onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="">Select Category</option>
                    {CATEGORIES.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Unit
                  </label>
                  <select
                    value={formData.unit}
                    onChange={(e) => setFormData(prev => ({ ...prev, unit: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="piece">Piece</option>
                    <option value="bottle">Bottle</option>
                    <option value="jar">Jar</option>
                    <option value="tube">Tube</option>
                    <option value="pack">Pack</option>
                    <option value="set">Set</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  rows={2}
                />
              </div>

              {/* Order Type Pricing Tabs */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Pricing by Order Type *
                </label>
                <div className="flex gap-2 mb-4">
                  {ORDER_TYPES.map(({ key, label }) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setActiveTab(key)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                        activeTab === key
                          ? 'bg-emerald-500 text-white'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {label}
                    </button>
                  ))}
                </div>

                <div className="bg-gray-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium text-gray-900">{getOrderTypeLabel(activeTab)} Price Tiers</h4>
                    <button
                      type="button"
                      onClick={() => addPriceTier(activeTab)}
                      className="text-sm text-emerald-600 hover:text-emerald-700"
                    >
                      + Add Tier
                    </button>
                  </div>
                  <div className="space-y-3">
                    {formData.pricing[activeTab].map((tier, index) => (
                      <div key={index} className="flex gap-3 items-center bg-white p-3 rounded-lg border border-gray-200">
                        <div className="flex-1">
                          <label className="text-xs text-gray-500">Min Qty</label>
                          <input
                            type="number"
                            min="1"
                            required
                            value={tier.minQuantity}
                            onChange={(e) => updatePriceTier(activeTab, index, 'minQuantity', parseInt(e.target.value) || 1)}
                            className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                        <div className="flex-1">
                          <label className="text-xs text-gray-500">Max Qty (empty = unlimited)</label>
                          <input
                            type="number"
                            min={tier.minQuantity}
                            value={tier.maxQuantity || ''}
                            onChange={(e) => updatePriceTier(activeTab, index, 'maxQuantity', e.target.value ? parseInt(e.target.value) : null)}
                            className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                            placeholder="∞"
                          />
                        </div>
                        <div className="flex-1">
                          <label className="text-xs text-gray-500">Price ({companySettings.currency})</label>
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            required
                            value={tier.price}
                            onChange={(e) => updatePriceTier(activeTab, index, 'price', parseFloat(e.target.value) || 0)}
                            className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                          />
                        </div>
                        {formData.pricing[activeTab].length > 1 && (
                          <button
                            type="button"
                            onClick={() => removePriceTier(activeTab, index)}
                            className="p-2 text-red-500 hover:bg-red-100 rounded-lg mt-5"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                  <p className="text-xs text-gray-400 mt-3">
                    Set different prices for {getOrderTypeLabel(activeTab)} orders based on quantity ranges.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Cost Price ({companySettings.currency}) *
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    step="0.01"
                    value={formData.costPrice}
                    onChange={(e) => setFormData(prev => ({ ...prev, costPrice: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Stock *
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={formData.stock}
                    onChange={(e) => setFormData(prev => ({ ...prev, stock: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Min Stock Alert
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formData.minStock}
                    onChange={(e) => setFormData(prev => ({ ...prev, minStock: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 px-4 py-2 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-gradient-to-r from-emerald-500 to-green-600 text-white rounded-lg hover:from-emerald-600 hover:to-green-700"
                >
                  {editingId ? 'Update Product' : 'Add Product'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
