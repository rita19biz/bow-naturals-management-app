import { useState } from 'react';
import { useApp } from '../context/AppContext';
import { format, parseISO, differenceInDays } from 'date-fns';
import { OrderType } from '../types';
import {
  Plus,
  Search,
  Edit2,
  Trash2,
  Eye,
  CheckCircle,
  Clock,
  Truck,
  Package,
  X,
  Phone,
  MapPin,
} from 'lucide-react';

interface OrderFormData {
  customerName: string;
  customerPhone: string;
  customerEmail: string;
  customerAddress: string;
  orderType: OrderType;
  products: { productId: string; quantity: number }[];
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  notes: string;
}

export default function CRM() {
  const {
    currentUser,
    users,
    products,
    logisticsCompanies,
    getFilteredCRM,
    addCRMEntry,
    updateCRMEntry,
    deleteCRMEntry,
    markAsDelivered,
    getProductPrice,
    selectedStaffId,
    setSelectedStaffId,
    companySettings,
  } = useApp();

  const isCEO = currentUser?.role === 'ceo';
  const staffId = isCEO ? selectedStaffId : currentUser?.id;
  const staffMembers = users.filter(u => u.role === 'staff');
  const crmEntries = getFilteredCRM(staffId);

  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [viewingEntry, setViewingEntry] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [orderTypeFilter, setOrderTypeFilter] = useState<string>('all');
  
  // Delivery modal states
  const [markDeliveryId, setMarkDeliveryId] = useState<string | null>(null);
  const [deliveryDateInput, setDeliveryDateInput] = useState<string>('');
  const [deliveryCostInput, setDeliveryCostInput] = useState<string>('0');
  const [deliveredFromInput, setDeliveredFromInput] = useState<string>('');

  // Edit delivery details modal (CEO only after delivered)
  const [editDeliveryId, setEditDeliveryId] = useState<string | null>(null);
  const [editDeliveryCost, setEditDeliveryCost] = useState<string>('');
  const [editDeliveredFrom, setEditDeliveredFrom] = useState<string>('');

  const [formData, setFormData] = useState<OrderFormData>({
    customerName: '',
    customerPhone: '',
    customerEmail: '',
    customerAddress: '',
    orderType: 'retail',
    products: [{ productId: '', quantity: 1 }],
    status: 'pending',
    notes: '',
  });

  const resetForm = () => {
    setFormData({
      customerName: '',
      customerPhone: '',
      customerEmail: '',
      customerAddress: '',
      orderType: 'retail',
      products: [{ productId: '', quantity: 1 }],
      status: 'pending',
      notes: '',
    });
    setEditingId(null);
    setShowForm(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const orderProducts = formData.products
      .filter(p => p.productId)
      .map(p => {
        const product = products.find(prod => prod.id === p.productId);
        const unitPrice = getProductPrice(p.productId, p.quantity, formData.orderType);
        return {
          productId: p.productId,
          productName: product?.name || '',
          quantity: p.quantity,
          unitPrice,
          total: unitPrice * p.quantity,
        };
      });

    const totalAmount = orderProducts.reduce((sum, p) => sum + p.total, 0);

    if (editingId) {
      updateCRMEntry(editingId, {
        ...formData,
        products: orderProducts,
        totalAmount,
      });
    } else {
      addCRMEntry({
        staffId: currentUser?.id || '',
        ...formData,
        products: orderProducts,
        totalAmount,
        actualDeliveryDate: null,
        deliveryCost: 0,
        deliveredFrom: null,
      });
    }
    resetForm();
  };

  const handleEdit = (entry: typeof crmEntries[0]) => {
    setFormData({
      customerName: entry.customerName,
      customerPhone: entry.customerPhone,
      customerEmail: entry.customerEmail,
      customerAddress: entry.customerAddress,
      orderType: entry.orderType || 'retail',
      products: entry.products.map(p => ({ productId: p.productId, quantity: p.quantity })),
      status: entry.status,
      notes: entry.notes,
    });
    setEditingId(entry.id);
    setShowForm(true);
  };

  const handleMarkDelivered = () => {
    if (markDeliveryId && deliveryDateInput && deliveredFromInput) {
      markAsDelivered(
        markDeliveryId, 
        deliveryDateInput, 
        parseFloat(deliveryCostInput) || 0,
        deliveredFromInput
      );
      setMarkDeliveryId(null);
      setDeliveryDateInput('');
      setDeliveryCostInput('0');
      setDeliveredFromInput('');
    }
  };

  const handleEditDeliveryDetails = () => {
    if (editDeliveryId) {
      updateCRMEntry(editDeliveryId, {
        deliveryCost: parseFloat(editDeliveryCost) || 0,
        deliveredFrom: editDeliveredFrom || null,
      });
      setEditDeliveryId(null);
      setEditDeliveryCost('');
      setEditDeliveredFrom('');
    }
  };

  const openEditDeliveryModal = (entry: typeof crmEntries[0]) => {
    setEditDeliveryId(entry.id);
    setEditDeliveryCost(entry.deliveryCost?.toString() || '0');
    setEditDeliveredFrom(entry.deliveredFrom || '');
  };

  const addProductRow = () => {
    setFormData(prev => ({
      ...prev,
      products: [...prev.products, { productId: '', quantity: 1 }],
    }));
  };

  const removeProductRow = (index: number) => {
    setFormData(prev => ({
      ...prev,
      products: prev.products.filter((_, i) => i !== index),
    }));
  };

  const updateProductRow = (index: number, field: 'productId' | 'quantity', value: string | number) => {
    setFormData(prev => ({
      ...prev,
      products: prev.products.map((p, i) => 
        i === index ? { ...p, [field]: value } : p
      ),
    }));
  };

  const filteredEntries = crmEntries.filter(entry => {
    const matchesSearch = entry.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         entry.customerPhone.includes(searchTerm);
    const matchesStatus = statusFilter === 'all' || entry.status === statusFilter;
    const matchesOrderType = orderTypeFilter === 'all' || entry.orderType === orderTypeFilter;
    return matchesSearch && matchesStatus && matchesOrderType;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-700';
      case 'processing': return 'bg-blue-100 text-blue-700';
      case 'shipped': return 'bg-purple-100 text-purple-700';
      case 'delivered': return 'bg-green-100 text-green-700';
      case 'cancelled': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getOrderTypeColor = (orderType: OrderType) => {
    switch (orderType) {
      case 'retail': return 'bg-blue-100 text-blue-700';
      case 'wholesale': return 'bg-purple-100 text-purple-700';
      case 'dm_group': return 'bg-orange-100 text-orange-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getOrderTypeLabel = (orderType: OrderType) => {
    switch (orderType) {
      case 'retail': return 'Retail';
      case 'wholesale': return 'Wholesale';
      case 'dm_group': return 'DM/Group';
      default: return orderType;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return Clock;
      case 'processing': return Package;
      case 'shipped': return Truck;
      case 'delivered': return CheckCircle;
      default: return Clock;
    }
  };

  const getLogisticsName = (id: string | null) => {
    if (!id) return '-';
    const company = logisticsCompanies.find(c => c.id === id);
    return company?.name || '-';
  };

  const viewEntry = crmEntries.find(e => e.id === viewingEntry);

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">CRM Dashboard</h1>
          <p className="text-gray-500">Manage customer orders and track deliveries</p>
        </div>
        <div className="flex items-center gap-3">
          {isCEO && (
            <select
              value={selectedStaffId}
              onChange={(e) => setSelectedStaffId(e.target.value)}
              className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
            >
              <option value="all">All Staff</option>
              {staffMembers.map(staff => (
                <option key={staff.id} value={staff.id}>{staff.name}</option>
              ))}
            </select>
          )}
          <button
            onClick={() => setShowForm(true)}
            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-500 to-green-600 text-white rounded-lg hover:from-emerald-600 hover:to-green-700 transition shadow-lg shadow-emerald-200"
          >
            <Plus className="w-5 h-5" />
            New Order
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <div className="flex-1 min-w-[200px] relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            placeholder="Search by customer name or phone..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
        >
          <option value="all">All Status</option>
          <option value="pending">Pending</option>
          <option value="processing">Processing</option>
          <option value="shipped">Shipped</option>
          <option value="delivered">Delivered</option>
          <option value="cancelled">Cancelled</option>
        </select>
        <select
          value={orderTypeFilter}
          onChange={(e) => setOrderTypeFilter(e.target.value)}
          className="px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
        >
          <option value="all">All Order Types</option>
          <option value="retail">Retail</option>
          <option value="wholesale">Wholesale</option>
          <option value="dm_group">DM/Group</option>
        </select>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Customer</th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Type</th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Products</th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Total</th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Delivered From</th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Follow-up</th>
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredEntries.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-gray-400">
                    No orders found
                  </td>
                </tr>
              ) : (
                filteredEntries.map((entry) => {
                  const StatusIcon = getStatusIcon(entry.status);
                  const daysUntilFollowUp = entry.followUpDate 
                    ? differenceInDays(parseISO(entry.followUpDate), new Date())
                    : null;

                  return (
                    <tr key={entry.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div>
                          <p className="font-medium text-gray-900">{entry.customerName}</p>
                          <p className="text-sm text-gray-500">{entry.customerPhone}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex px-2.5 py-1 rounded-full text-xs font-medium ${getOrderTypeColor(entry.orderType || 'retail')}`}>
                          {getOrderTypeLabel(entry.orderType || 'retail')}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-sm text-gray-600">
                          {entry.products.length} item(s)
                        </p>
                      </td>
                      <td className="px-6 py-4">
                        <p className="font-semibold text-gray-900">
                          {companySettings.currency}{entry.totalAmount.toLocaleString()}
                        </p>
                        {entry.status === 'delivered' && entry.deliveryCost > 0 && (
                          <p className="text-xs text-gray-500">
                            +{companySettings.currency}{entry.deliveryCost.toLocaleString()} delivery
                          </p>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${getStatusColor(entry.status)}`}>
                          <StatusIcon className="w-3.5 h-3.5" />
                          {entry.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-gray-400" />
                          <span className="text-sm text-gray-600">
                            {getLogisticsName(entry.deliveredFrom)}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        {entry.followUpDate ? (
                          <div>
                            <p className="text-sm text-gray-600">
                              {format(parseISO(entry.followUpDate), 'MMM d, yyyy')}
                            </p>
                            <span className={`text-xs ${
                              entry.followUpStatus === 'overdue' ? 'text-red-600' :
                              entry.followUpStatus === 'completed' ? 'text-green-600' : 'text-orange-600'
                            }`}>
                              {entry.followUpStatus === 'overdue' ? `${Math.abs(daysUntilFollowUp || 0)} days overdue` :
                               entry.followUpStatus === 'completed' ? 'Completed' :
                               `In ${daysUntilFollowUp} days`}
                            </span>
                          </div>
                        ) : (
                          <span className="text-sm text-gray-400">-</span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setViewingEntry(entry.id)}
                            className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition"
                            title="View"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          {entry.status !== 'delivered' && entry.status !== 'cancelled' && (
                            <>
                              <button
                                onClick={() => handleEdit(entry)}
                                className="p-2 text-gray-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition"
                                title="Edit"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => {
                                  setMarkDeliveryId(entry.id);
                                  setDeliveryDateInput(format(new Date(), 'yyyy-MM-dd'));
                                  setDeliveryCostInput('0');
                                  setDeliveredFromInput('');
                                }}
                                className="p-2 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition"
                                title="Mark as Delivered"
                              >
                                <CheckCircle className="w-4 h-4" />
                              </button>
                            </>
                          )}
                          {/* CEO can edit delivery details after delivered */}
                          {isCEO && entry.status === 'delivered' && (
                            <button
                              onClick={() => openEditDeliveryModal(entry)}
                              className="p-2 text-gray-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition"
                              title="Edit Delivery Details"
                            >
                              <Truck className="w-4 h-4" />
                            </button>
                          )}
                          {entry.followUpStatus === 'pending' && (
                            <button
                              onClick={() => updateCRMEntry(entry.id, { followUpStatus: 'completed' })}
                              className="p-2 text-gray-400 hover:text-purple-600 hover:bg-purple-50 rounded-lg transition"
                              title="Complete Follow-up"
                            >
                              <Phone className="w-4 h-4" />
                            </button>
                          )}
                          <button
                            onClick={() => {
                              if (confirm('Are you sure you want to delete this order?')) {
                                deleteCRMEntry(entry.id);
                              }
                            }}
                            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mark Delivery Modal */}
      {markDeliveryId && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-xl">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Mark as Delivered</h3>
            <p className="text-sm text-gray-500 mb-4">
              Enter delivery details. A follow-up will be automatically scheduled for 30 days after delivery.
            </p>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Date *</label>
                <input
                  type="date"
                  value={deliveryDateInput}
                  onChange={(e) => setDeliveryDateInput(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Delivered From (Location) *</label>
                <select
                  value={deliveredFromInput}
                  onChange={(e) => setDeliveredFromInput(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  required
                >
                  <option value="">Select Logistics Location</option>
                  {logisticsCompanies.map(company => (
                    <option key={company.id} value={company.id}>{company.name}</option>
                  ))}
                </select>
                <p className="text-xs text-gray-400 mt-1">
                  Inventory will be automatically deducted from this location
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Cost ({companySettings.currency})</label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={deliveryCostInput}
                  onChange={(e) => setDeliveryCostInput(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  placeholder="0"
                />
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => {
                  setMarkDeliveryId(null);
                  setDeliveryDateInput('');
                  setDeliveryCostInput('0');
                  setDeliveredFromInput('');
                }}
                className="flex-1 px-4 py-2 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleMarkDelivered}
                disabled={!deliveredFromInput}
                className="flex-1 px-4 py-2 bg-gradient-to-r from-emerald-500 to-green-600 text-white rounded-lg hover:from-emerald-600 hover:to-green-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Confirm Delivery
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Edit Delivery Details Modal (CEO Only) */}
      {editDeliveryId && isCEO && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md shadow-xl">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Edit Delivery Details</h3>
            <p className="text-sm text-gray-500 mb-4">
              Update delivery cost and location for this delivered order.
            </p>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Delivered From (Location)</label>
                <select
                  value={editDeliveredFrom}
                  onChange={(e) => setEditDeliveredFrom(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="">Select Logistics Location</option>
                  {logisticsCompanies.map(company => (
                    <option key={company.id} value={company.id}>{company.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Delivery Cost ({companySettings.currency})</label>
                <input
                  type="number"
                  min="0"
                  step="0.01"
                  value={editDeliveryCost}
                  onChange={(e) => setEditDeliveryCost(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  placeholder="0"
                />
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => {
                  setEditDeliveryId(null);
                  setEditDeliveryCost('');
                  setEditDeliveredFrom('');
                }}
                className="flex-1 px-4 py-2 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                onClick={handleEditDeliveryDetails}
                className="flex-1 px-4 py-2 bg-gradient-to-r from-emerald-500 to-green-600 text-white rounded-lg hover:from-emerald-600 hover:to-green-700"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {/* View Order Modal */}
      {viewEntry && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">Order Details</h3>
              <button
                onClick={() => setViewingEntry(null)}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(viewEntry.status)}`}>
                    {viewEntry.status}
                  </span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getOrderTypeColor(viewEntry.orderType || 'retail')}`}>
                    {getOrderTypeLabel(viewEntry.orderType || 'retail')}
                  </span>
                </div>
                <p className="text-sm text-gray-500">
                  Created: {format(parseISO(viewEntry.createdAt), 'MMM d, yyyy h:mm a')}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-500 mb-1">Customer Name</p>
                  <p className="font-medium text-gray-900">{viewEntry.customerName}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-500 mb-1">Phone</p>
                  <p className="font-medium text-gray-900">{viewEntry.customerPhone}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-500 mb-1">Email</p>
                  <p className="font-medium text-gray-900">{viewEntry.customerEmail || '-'}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-500 mb-1">Address</p>
                  <p className="font-medium text-gray-900">{viewEntry.customerAddress}</p>
                </div>
              </div>

              <div>
                <h4 className="font-medium text-gray-900 mb-3">Products</h4>
                <div className="border border-gray-200 rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="text-left px-4 py-2 text-xs font-medium text-gray-500">Product</th>
                        <th className="text-center px-4 py-2 text-xs font-medium text-gray-500">Qty</th>
                        <th className="text-right px-4 py-2 text-xs font-medium text-gray-500">Unit Price</th>
                        <th className="text-right px-4 py-2 text-xs font-medium text-gray-500">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {viewEntry.products.map((p, i) => (
                        <tr key={i}>
                          <td className="px-4 py-3 text-sm text-gray-900">{p.productName}</td>
                          <td className="px-4 py-3 text-sm text-gray-600 text-center">{p.quantity}</td>
                          <td className="px-4 py-3 text-sm text-gray-600 text-right">
                            {companySettings.currency}{p.unitPrice.toLocaleString()}
                          </td>
                          <td className="px-4 py-3 text-sm font-medium text-gray-900 text-right">
                            {companySettings.currency}{p.total.toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-gray-50">
                      <tr>
                        <td colSpan={3} className="px-4 py-3 text-sm font-medium text-gray-900 text-right">
                          Subtotal:
                        </td>
                        <td className="px-4 py-3 text-sm font-bold text-emerald-600 text-right">
                          {companySettings.currency}{viewEntry.totalAmount.toLocaleString()}
                        </td>
                      </tr>
                      {viewEntry.deliveryCost > 0 && (
                        <tr>
                          <td colSpan={3} className="px-4 py-3 text-sm font-medium text-gray-900 text-right">
                            Delivery Cost:
                          </td>
                          <td className="px-4 py-3 text-sm font-bold text-orange-600 text-right">
                            {companySettings.currency}{viewEntry.deliveryCost.toLocaleString()}
                          </td>
                        </tr>
                      )}
                    </tfoot>
                  </table>
                </div>
              </div>

              {viewEntry.actualDeliveryDate && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-green-50 rounded-lg p-4">
                    <p className="text-sm text-green-600 mb-1">Actual Delivery Date</p>
                    <p className="font-medium text-green-700">
                      {format(parseISO(viewEntry.actualDeliveryDate), 'MMM d, yyyy')}
                    </p>
                  </div>
                  <div className="bg-blue-50 rounded-lg p-4">
                    <p className="text-sm text-blue-600 mb-1">Delivered From</p>
                    <p className="font-medium text-blue-700">
                      {getLogisticsName(viewEntry.deliveredFrom)}
                    </p>
                  </div>
                  <div className="bg-orange-50 rounded-lg p-4">
                    <p className="text-sm text-orange-600 mb-1">Delivery Cost</p>
                    <p className="font-medium text-orange-700">
                      {companySettings.currency}{(viewEntry.deliveryCost || 0).toLocaleString()}
                    </p>
                  </div>
                  <div className={`rounded-lg p-4 ${
                    viewEntry.followUpStatus === 'overdue' ? 'bg-red-50' :
                    viewEntry.followUpStatus === 'completed' ? 'bg-green-50' : 'bg-orange-50'
                  }`}>
                    <p className={`text-sm mb-1 ${
                      viewEntry.followUpStatus === 'overdue' ? 'text-red-600' :
                      viewEntry.followUpStatus === 'completed' ? 'text-green-600' : 'text-orange-600'
                    }`}>
                      Follow-up Date (30 days)
                    </p>
                    <p className={`font-medium ${
                      viewEntry.followUpStatus === 'overdue' ? 'text-red-700' :
                      viewEntry.followUpStatus === 'completed' ? 'text-green-700' : 'text-orange-700'
                    }`}>
                      {viewEntry.followUpDate ? format(parseISO(viewEntry.followUpDate), 'MMM d, yyyy') : '-'}
                      <span className="text-xs ml-2">({viewEntry.followUpStatus})</span>
                    </p>
                  </div>
                </div>
              )}

              {viewEntry.notes && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-500 mb-1">Notes</p>
                  <p className="text-gray-900">{viewEntry.notes}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Add/Edit Order Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between sticky top-0 bg-white">
              <h3 className="text-lg font-semibold text-gray-900">
                {editingId ? 'Edit Order' : 'New Order'}
              </h3>
              <button
                onClick={resetForm}
                className="p-2 hover:bg-gray-100 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Customer Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.customerName}
                    onChange={(e) => setFormData(prev => ({ ...prev, customerName: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.customerPhone}
                    onChange={(e) => setFormData(prev => ({ ...prev, customerPhone: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    value={formData.customerEmail}
                    onChange={(e) => setFormData(prev => ({ ...prev, customerEmail: e.target.value }))}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Order Type *
                  </label>
                  <select
                    value={formData.orderType}
                    onChange={(e) => setFormData(prev => ({ ...prev, orderType: e.target.value as OrderType }))}
                    className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="retail">Retail</option>
                    <option value="wholesale">Wholesale</option>
                    <option value="dm_group">DM/Group</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Address *
                </label>
                <textarea
                  required
                  value={formData.customerAddress}
                  onChange={(e) => setFormData(prev => ({ ...prev, customerAddress: e.target.value }))}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  rows={2}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Status
                </label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value as OrderFormData['status'] }))}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="pending">Pending</option>
                  <option value="processing">Processing</option>
                  <option value="shipped">Shipped</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-3">
                  <label className="text-sm font-medium text-gray-700">Products *</label>
                  <button
                    type="button"
                    onClick={addProductRow}
                    className="text-sm text-emerald-600 hover:text-emerald-700"
                  >
                    + Add Product
                  </button>
                </div>
                <p className="text-xs text-gray-400 mb-3">
                  Prices are automatically calculated based on order type ({getOrderTypeLabel(formData.orderType)}) and quantity
                </p>
                <div className="space-y-3">
                  {formData.products.map((product, index) => {
                    const unitPrice = product.productId ? getProductPrice(product.productId, product.quantity, formData.orderType) : 0;
                    
                    return (
                      <div key={index} className="flex gap-3 items-start">
                        <select
                          value={product.productId}
                          onChange={(e) => updateProductRow(index, 'productId', e.target.value)}
                          className="flex-1 px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                          required
                        >
                          <option value="">Select Product</option>
                          {products.map(p => (
                            <option key={p.id} value={p.id}>{p.name}</option>
                          ))}
                        </select>
                        <input
                          type="number"
                          min="1"
                          value={product.quantity}
                          onChange={(e) => updateProductRow(index, 'quantity', parseInt(e.target.value) || 1)}
                          className="w-24 px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                          placeholder="Qty"
                        />
                        <div className="w-32 px-4 py-2 bg-gray-50 rounded-lg text-sm">
                          {companySettings.currency}{(unitPrice * product.quantity).toLocaleString()}
                        </div>
                        {formData.products.length > 1 && (
                          <button
                            type="button"
                            onClick={() => removeProductRow(index)}
                            className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                          >
                            <X className="w-5 h-5" />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Notes
                </label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                  className="w-full px-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-emerald-500"
                  rows={3}
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={resetForm}
                  className="flex-1 px-4 py-2 border border-gray-200 text-gray-600 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-gradient-to-r from-emerald-500 to-green-600 text-white rounded-lg hover:from-emerald-600 hover:to-green-700"
                >
                  {editingId ? 'Update Order' : 'Create Order'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
